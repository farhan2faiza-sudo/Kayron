# Kayron v6 (Android)

Orange-and-black chat that writes code, paints pictures, answers anything and controls your phone.

## What is new in v6

- **No API key needed.** Kayron has a free AI built in (Pollinations for answers and pictures, AI Horde as a spare painter).
  A Gemini key in settings is now optional: if you add one, Kayron uses Gemini first and keeps the free AI as a safety net.
  These are free third-party services, so they can be slower, busy, or change. Everything you send (and anything you ask
  Kayron to read: screen, notifications, emails) goes to that online service. A one-time notice explains this.
- **Pictures:** "draw a sunset over the mountains", "generate an image of a red car", "/imagine ...". Tap Save or Share under the picture.
- **Live steps:** right under your message, on the left, Kayron writes what it is doing ("🧠 Thinking", "⚡ open instagram", "↕️ Scrolling down" ...).
- **Real accounts:** each Gmail account has its own password, its own chats, memory and pictures.
  - Chats are encrypted (AES-GCM) with a key that only the password can open. The password is never saved.
  - The saved key is also sealed inside the phone's secure hardware (Android Keystore).
  - Wrong passwords are slowed down (after 5 mistakes: 30 s, 60 s, 2 min ... up to 15 min).
  - Auto-lock when you leave the app (Settings > Account > Auto-lock). Switching account locks the old one.
  - A recovery code is shown once when you create an account. It is the only way back in if you forget the password.
  - Account screens are hidden from screenshots and the recent-apps preview (this also blocks your own screenshots).
  - **Gmail features** (read, search, send) only work for the open account, after "Verify with Google" proves the address is yours.
    Guest never has Gmail access. Kayron never sends an email without showing you the draft and getting your "yes".
- **New logo:** the Kayron ring is now the app icon too. The flame is gone.

## Using it

- Start screen with the rotating Kayron ring. When you send the first message the ring shrinks to the top left.
- Many chats: swipe right (or tap the menu). Hold an account in the list for its options (lock, verify, change password, delete).
- Code mode: the </> button forces it. It writes code, then a second pass reviews it.
- Phone orders: "next reel", "scroll down", "auto scroll every 10 seconds", "open <app>", "call <name>", "read my notifications"...

Setup: open the app, then "Set up Kayron" (gear > Set up Kayron) to turn on Accessibility, notification access and contacts.

## Gmail verification (optional, needed only for reading/sending email)

Signing key: app/kayron.keystore (password kayron-build-key). SHA-1 for the Gmail OAuth client:
0C:4A:A2:6E:4B:B3:E9:97:E4:FD:A6:19:0E:25:F6:65:E0:5C:F6:5F
For a public release, make your own private key and do not publish it.

Google Cloud > enable Gmail API > OAuth consent (External, add yourself as a test user,
scopes gmail.readonly and gmail.send) > Credentials > OAuth client ID > Android > package com.kayron.mobile + the SHA-1 above.

Accounts, passwords and chats work without this step. Only "Verify with Google" and the Gmail features need it.

## Upgrading from v5

Gmail accounts made in v5 have no password. The first time you open one, Kayron asks you to set a password and
then encrypts the old chats of that account.
