plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kayron.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kayron.mobile"
        minSdk = 30
        targetSdk = 35
        versionCode = 6
        versionName = "6.0"
    }

    // One fixed key: updates install over the old app, and the Gmail sign-in fingerprint never changes.
    signingConfigs {
        create("kayron") {
            storeFile = file("kayron.keystore")
            storeType = "pkcs12"
            storePassword = "kayron-build-key"
            keyAlias = "kayron"
            keyPassword = "kayron-build-key"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("kayron") }
        release {
            signingConfig = signingConfigs.getByName("kayron")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.android.gms:play-services-auth:21.2.0") // Google sign-in for Gmail
}
