package com.kayron.mobile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import kotlin.math.abs

/** Kayron: a chat that writes code, paints pictures, answers anything and controls your phone. Orange and black. */
class MainActivity : Activity() {
    private val BG = Color.parseColor("#0A0A0A")
    private val ORANGE = Color.parseColor("#FF8C1E")
    private val GREY = Color.parseColor("#8A8A8A")
    private val RED = Color.parseColor("#FF6A4A")

    private lateinit var rootFrame: FrameLayout
    private lateinit var column: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var empty: LinearLayout
    private lateinit var ring: RingView
    private lateinit var ringSlot: View
    private lateinit var ringHome: View
    private lateinit var drawer: LinearLayout
    private lateinit var drawerBody: LinearLayout
    private lateinit var scrim: View
    private lateinit var codeBtn: TextView

    // lock screen
    private lateinit var lockView: FrameLayout
    private lateinit var lockEmail: TextView
    private lateinit var lockPw: EditText
    private lateinit var lockMsg: TextView
    private lateinit var lockBtn: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val RING = 200
    private var drawerOpen = false
    private var drawerW = 0
    private var ringAtHeader = false
    private var ringAnimating = false
    private var codeForced = false
    private var working = false
    private var workCode = false
    private var workStart = 0L
    private var progressNote = ""
    private var statusJob: Runnable? = null
    private var hasMessages = false
    private var downX = 0f
    private var downY = 0f
    private var uiLocked = false
    private var chatLoaded = false
    private var leftAt = 0L
    private var verifyFor: String? = null
    private lateinit var profile: String
    private lateinit var chatId: String

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    private fun pill(bg: Int, r: Int = 14) = GradientDrawable().apply {
        setColor(bg); cornerRadius = r.dp().toFloat()
    }

    private fun brand(r: Int) = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.parseColor("#FF9A2E"), Color.parseColor("#FF5A1A"))
    ).apply { cornerRadius = r.dp().toFloat() }

    private fun tv(s: String, sz: Float, col: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sz; setTextColor(col)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pwField(hint: String) = EditText(this).apply {
        this.hint = hint; setSingleLine(); textSize = 14f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    // =====================================================================
    //  screen
    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        drawerW = (resources.displayMetrics.widthPixels * 0.82f).toInt()

        rootFrame = FrameLayout(this).apply { setBackgroundColor(BG) }
        column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rootFrame.addView(column, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // ---- header: ring (top left) + name + what Kayron is doing ----
        ringSlot = View(this)
        status = tv("", 12f, GREY)
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Kayron", 18f, Color.WHITE, true))
            addView(status)
        }
        column.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ringSlot, LinearLayout.LayoutParams(44.dp(), 44.dp()).apply { rightMargin = 12.dp() })
            addView(names)
            addView(View(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(tv("☰", 22f).apply {
                setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp()); setOnClickListener { openDrawer() }
            })
            addView(tv("⚙", 24f).apply {
                setPadding(8.dp(), 8.dp(), 4.dp(), 8.dp()); setOnClickListener { settings() }
            })
        })

        // ---- messages + the start screen ----
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8.dp(), 0, 16.dp())
        }
        scroll = ScrollView(this).apply { addView(list) }

        ringHome = View(this)
        empty = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(ringHome, LinearLayout.LayoutParams(RING.dp(), RING.dp()))
            addView(tv("I can write code, paint pictures, answer anything and run your phone", 12f, ORANGE).apply {
                gravity = Gravity.CENTER; setPadding(12.dp(), 0, 12.dp(), 6.dp())
            })
            addView(tv("What Can I Do for You Today?", 26f, Color.parseColor("#FFD2A0"), true).apply {
                gravity = Gravity.CENTER; setPadding(12.dp(), 0, 12.dp(), 12.dp())
            })
            for (q in listOf("🎨 Draw a sunset over the mountains", "💻 Build me a Snake game in HTML", "🔔 Read my notifications")) {
                addView(tv(q, 14f, Color.parseColor("#CCCCCC")).apply {
                    setPadding(16.dp(), 10.dp(), 16.dp(), 10.dp())
                    background = pill(Color.parseColor("#151515"), 20)
                    setOnClickListener { send(q.substring(q.indexOf(' ') + 1)) }
                }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
            }
        }
        val frame = FrameLayout(this).apply {
            addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(empty, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER))
        }
        column.addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // ---- the search / message widget ----
        input = EditText(this).apply {
            hint = "Search or ask Kayron…"
            setHintTextColor(Color.parseColor("#6E6E6E"))
            setTextColor(Color.WHITE)
            textSize = 16f
            background = null
            maxLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        codeBtn = tv("</>", 14f, GREY, true).apply {
            setPadding(10.dp(), 6.dp(), 10.dp(), 6.dp())
            setOnClickListener {
                codeForced = !codeForced
                setTextColor(if (codeForced) ORANGE else GREY)
                note(if (codeForced) "Code mode is ON. Every message will be treated as a coding job." else "Code mode is OFF. Kayron decides by itself.")
            }
        }
        val go = tv("➤", 22f, ORANGE).apply {
            setPadding(8.dp(), 6.dp(), 6.dp(), 6.dp()); setOnClickListener { send(input.text.toString()) }
        }
        column.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp(), 4.dp(), 10.dp(), 4.dp())
            background = pill(Color.parseColor("#121212"), 28).apply { setStroke(1.dp(), Color.parseColor("#44FF8C1E")) }
            addView(tv("🔍", 16f).apply { setPadding(0, 0, 8.dp(), 0) })
            addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(codeBtn); addView(go)
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })

        // ---- the ring (one view that travels between the middle and the top left) ----
        ring = RingView(this).apply { pivotX = 0f; pivotY = 0f }
        rootFrame.addView(ring, FrameLayout.LayoutParams(RING.dp(), RING.dp()))

        // ---- chats drawer ----
        scrim = View(this).apply {
            setBackgroundColor(Color.parseColor("#99000000")); visibility = View.GONE; alpha = 0f
            setOnClickListener { closeDrawer() }
        }
        rootFrame.addView(scrim, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        drawerBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14.dp(), 6.dp(), 14.dp(), 14.dp()) }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F0F10"))
            visibility = View.GONE
            translationX = -drawerW.toFloat()
            addView(ScrollView(this@MainActivity).apply { addView(drawerBody) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(tv("⚙  Settings", 15f, Color.parseColor("#DDDDDD")).apply {
                setPadding(22.dp(), 16.dp(), 22.dp(), 16.dp()); setOnClickListener { closeDrawer(); settings() }
            })
        }
        rootFrame.addView(drawer, FrameLayout.LayoutParams(drawerW, MATCH_PARENT))

        // ---- the lock screen (covers everything while an account is locked) ----
        buildLock()
        rootFrame.addView(lockView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        rootFrame.setOnApplyWindowInsetsListener { _, ins -> // stay clear of the bars and the keyboard
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            column.setPadding(16.dp(), i.top + 10.dp(), 16.dp(), i.bottom + 10.dp())
            drawer.setPadding(0, i.top, 0, i.bottom)
            lockView.setPadding(0, i.top, 0, i.bottom)
            ins
        }
        rootFrame.viewTreeObserver.addOnGlobalLayoutListener { if (!ringAnimating) snapRing() }

        setContentView(rootFrame)

        profile = Prefs.profile(this)
        var legacy: String? = null
        if (profile != "guest" && !Vault.exists(this, profile)) {
            // an account made by an older Kayron: it has no password yet, so it must get one first
            legacy = profile
            profile = "guest"
            Prefs.setProfile(this, "guest")
        }
        if (profile != "guest" && !Vault.isUnlocked(profile)) {
            showLock()
        } else {
            chooseChat()
            loadChat(false)
        }
        applySecure()
        refreshStatus()
        if (intent.getBooleanExtra("setup", false)) checklist()
        if (legacy != null) {
            val p = legacy
            ui.post { createAccountDialog(p) }
        } else if (!Prefs.noticeShown(this)) ui.post { notice() }
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    override fun onStart() { super.onStart(); maybeLock() }

    override fun onStop() { super.onStop(); leftAt = System.currentTimeMillis() }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (i.getBooleanExtra("setup", false)) checklist()
    }

    override fun onBackPressed() { if (drawerOpen) closeDrawer() else super.onBackPressed() }

    /** Swipe right to open your chats, swipe left to close them. */
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (uiLocked) return super.dispatchTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                val w = resources.displayMetrics.widthPixels
                if (!drawerOpen && dx > 110.dp() && abs(dy) < 70.dp() && downX < w * 0.45f) openDrawer()
                else if (drawerOpen && dx < -110.dp() && abs(dy) < 90.dp()) closeDrawer()
            }
        }
        return super.dispatchTouchEvent(e)
    }

    // =====================================================================
    //  the ring
    // =====================================================================
    private fun posIn(v: View): Pair<Float, Float> {
        val a = IntArray(2); val r = IntArray(2)
        v.getLocationInWindow(a); rootFrame.getLocationInWindow(r)
        return Pair((a[0] - r[0]).toFloat(), (a[1] - r[1]).toFloat())
    }

    private fun smallScale() = 44.dp().toFloat() / RING.dp()

    /** Put the ring exactly where it belongs, with no animation. */
    private fun snapRing() {
        val target = if (ringAtHeader) ringSlot else ringHome
        if (target.width == 0) return
        val (x, y) = posIn(target)
        val s = if (ringAtHeader) smallScale() else 1f
        ring.x = x; ring.y = y; ring.scaleX = s; ring.scaleY = s
    }

    /** Big ring in the middle shrinks and flies to the top left while spinning fast. */
    private fun ringToHeader() {
        ringAtHeader = true
        val (x, y) = posIn(ringSlot)
        ringAnimating = true
        ring.speed = 5f
        ring.animate().x(x).y(y).scaleX(smallScale()).scaleY(smallScale())
            .setDuration(900).setInterpolator(DecelerateInterpolator(1.6f))
            .withEndAction { ringAnimating = false; applyRingSpeed(); snapRing() }.start()
        empty.animate().alpha(0f).setDuration(350)
            .withEndAction { empty.visibility = View.GONE; empty.alpha = 1f }.start()
    }

    private fun ringToCenter() {
        ringAtHeader = false
        empty.alpha = 0f
        empty.visibility = View.VISIBLE
        rootFrame.post {
            val (x, y) = posIn(ringHome)
            ringAnimating = true
            ring.speed = 4f
            ring.animate().x(x).y(y).scaleX(1f).scaleY(1f)
                .setDuration(700).setInterpolator(DecelerateInterpolator(1.6f))
                .withEndAction { ringAnimating = false; applyRingSpeed(); snapRing() }.start()
            empty.animate().alpha(1f).setDuration(500).start()
        }
    }

    private fun applyRingSpeed() { ring.speed = if (working) 3.2f else 1f }

    // =====================================================================
    //  status: what Kayron is doing, next to the ring
    // =====================================================================
    private fun refreshStatus() {
        if (working) return
        val who = if (profile == "guest") "Guest" else profile
        val badge = if (profile == "guest") "" else if (Vault.verified(this, profile)) " 🔒✔" else " 🔒"
        val engine = if (Prefs.key(this).isNotBlank()) "Gemini ${Usage.today(this)}/${Prefs.dailyLimit(this)}" else "Free AI"
        status.setTextColor(GREY)
        status.text = "$who$badge · $engine"
    }

    private fun setWorking(on: Boolean, code: Boolean) {
        working = on; workCode = code
        workStart = System.currentTimeMillis(); progressNote = ""
        applyRingSpeed()
        statusJob?.let { ui.removeCallbacks(it) }; statusJob = null
        if (on) {
            var n = 0
            val r = object : Runnable {
                override fun run() {
                    n = (n + 1) % 4
                    val phase = progressNote.trimEnd('.', '…').ifEmpty { "Thinking" }
                    status.setTextColor(ORANGE)
                    status.text = phase + ".".repeat(n)
                    ui.postDelayed(this, 380)
                }
            }
            statusJob = r; ui.post(r)
        } else refreshStatus()
    }

    // =====================================================================
    //  live steps: what Kayron is doing, written under your message on the left
    // =====================================================================
    private class StepsView(val card: LinearLayout, val lines: LinearLayout, val head: TextView, val spinner: RingView) {
        var n = 0
        var last = ""
    }

    private fun startSteps(): StepsView {
        val lines = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val spinner = RingView(this).apply { speed = 4f; strokeBoost = 3.5f }
        val head = tv("Kayron is working…", 13f, ORANGE, true)
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(spinner, LinearLayout.LayoutParams(24.dp(), 24.dp()).apply { rightMargin = 8.dp() })
            addView(head)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12.dp(), 8.dp(), 16.dp(), 8.dp())
            background = pill(Color.parseColor("#120E0A"), 16).apply { setStroke(1.dp(), Color.parseColor("#33FF8C1E")) }
            addView(top)
            addView(lines)
        }
        list.addView(card, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp(); gravity = Gravity.START })
        scrollDown()
        return StepsView(card, lines, head, spinner)
    }

    private fun stepAdd(s: StepsView, text: String) {
        val t = text.trim()
        if (t.isEmpty() || t == s.last) return
        s.last = t; s.n++
        s.lines.addView(tv(t, 13f, Color.parseColor("#D9C7B2")).apply { setPadding(2.dp(), 3.dp(), 0, 3.dp()) })
        s.head.text = "Kayron is working… (${s.n})"
        scrollDown()
    }

    private fun stepsDone(s: StepsView) {
        s.spinner.visibility = View.GONE
        if (s.n == 0) { list.removeView(s.card); return }
        s.head.text = "✅ Done · ${s.n} step" + (if (s.n == 1) "" else "s") + "  ▾"
        s.head.setTextColor(GREY)
        if (s.n > 4) s.lines.visibility = View.GONE
        s.card.setOnClickListener {
            s.lines.visibility = if (s.lines.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    // =====================================================================
    //  messages
    // =====================================================================
    private fun userBubble(text: String) {
        val t = TextView(this).apply {
            this.text = text; textSize = 15.5f; setTextColor(Color.WHITE)
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            background = brand(18)
            maxWidth = (resources.displayMetrics.widthPixels * 0.80f).toInt()
            setTextIsSelectable(true)
        }
        list.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 10.dp(); gravity = Gravity.END })
        empty.visibility = View.GONE
    }

    private fun note(msg: String) {
        val t = tv(msg, 13f, GREY).apply { setPadding(6.dp(), 4.dp(), 6.dp(), 4.dp()) }
        list.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
        empty.visibility = View.GONE
        scrollDown()
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun cleanText(s: String): String = s
        .replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        .replace(Regex("(?m)^\\s*[*-]\\s+"), "• ")

    private fun spans(src: String): CharSequence {
        val sb = SpannableStringBuilder()
        var i = 0
        while (i < src.length) {
            if (src.startsWith("**", i)) {
                val e = src.indexOf("**", i + 2)
                if (e > 0) {
                    val s = sb.length
                    sb.append(src.substring(i + 2, e))
                    sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = e + 2; continue
                }
            }
            if (src[i] == '`') {
                val e = src.indexOf('`', i + 1)
                if (e > 0) {
                    val s = sb.length
                    sb.append(src.substring(i + 1, e))
                    sb.setSpan(TypefaceSpan("monospace"), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(Color.parseColor("#FFB86B")), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = e + 1; continue
                }
            }
            sb.append(src[i]); i++
        }
        return sb
    }

    private fun decodeSmall(b: ByteArray, max: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeByteArray(b, 0, b.size, o2)
    }

    /** Saves a picture into Pictures/Kayron in the gallery. Needs no permission on Android 10 and newer. */
    private fun saveToGallery(b: ByteArray): Uri? = try {
        val ext = if (b.size > 4 && b[0] == 0x89.toByte()) "png" else if (b.size > 12 && b[8] == 'W'.code.toByte()) "webp" else "jpg"
        val mime = when (ext) { "png" -> "image/png"; "webp" -> "image/webp"; else -> "image/jpeg" }
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, "Kayron_" + System.currentTimeMillis() + "." + ext)
        v.put(MediaStore.Images.Media.MIME_TYPE, mime)
        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Kayron")
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        if (u != null) contentResolver.openOutputStream(u)?.use { it.write(b) }
        u
    } catch (e: Exception) {
        null
    }

    /** A Kayron reply: normal text in bubbles, code in cards with Copy and Share, pictures with Save and Share. */
    private fun replyView(text: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pf = profile
        fun addText(s: String) {
            val t = s.trim('\n', ' ')
            if (t.isEmpty()) return
            col.addView(TextView(this).apply {
                this.text = spans(cleanText(t)); textSize = 15.5f; setTextColor(Color.parseColor("#EDEDED"))
                setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
                background = pill(Color.parseColor("#151515"), 18)
                maxWidth = (resources.displayMetrics.widthPixels * 0.90f).toInt()
                setLineSpacing(0f, 1.12f)
                setTextIsSelectable(true)
            }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp(); gravity = Gravity.START })
        }
        fun addImage(name: String) {
            val iv = ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = pill(Color.parseColor("#151515"), 16)
                clipToOutline = true
                minimumHeight = 160.dp()
            }
            val bytesBox = arrayOfNulls<ByteArray>(1)
            val uriBox = arrayOfNulls<Uri>(1)
            Thread {
                val bytes = Images.load(this@MainActivity, pf, name)
                val bmp = if (bytes != null) decodeSmall(bytes, 1080) else null
                runOnUiThread {
                    if (bmp != null) { iv.setImageBitmap(bmp); bytesBox[0] = bytes }
                }
            }.start()
            fun saved(): Uri? {
                val b = bytesBox[0] ?: return null
                if (uriBox[0] == null) uriBox[0] = saveToGallery(b)
                return uriBox[0]
            }
            val buttons = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(tv("💾 Save", 13f, ORANGE, true).apply {
                    setPadding(4.dp(), 8.dp(), 14.dp(), 6.dp())
                    setOnClickListener {
                        val u = saved()
                        Toast.makeText(this@MainActivity, if (u != null) "Saved in Pictures/Kayron 📷" else "Could not save the picture", Toast.LENGTH_SHORT).show()
                    }
                })
                addView(tv("↗ Share", 13f, ORANGE, true).apply {
                    setPadding(8.dp(), 8.dp(), 14.dp(), 6.dp())
                    setOnClickListener {
                        val u = saved()
                        if (u != null) {
                            startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("image/*").putExtra(Intent.EXTRA_STREAM, u)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share picture"))
                        }
                    }
                })
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(iv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
                addView(buttons)
            }
            col.addView(card, LinearLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.86f).toInt(), WRAP_CONTENT)
                .apply { topMargin = 8.dp(); gravity = Gravity.START })
        }
        fun addTextAndImages(s: String) {
            val re = Regex("\\[\\[img:([A-Za-z0-9._-]+)\\]\\]")
            var p = 0
            for (m in re.findAll(s)) {
                addText(s.substring(p, m.range.first))
                addImage(m.groupValues[1])
                p = m.range.last + 1
            }
            addText(s.substring(p))
        }
        fun addCode(lang: String, code: String) {
            val head = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14.dp(), 8.dp(), 8.dp(), 8.dp())
                addView(tv(lang.ifBlank { "code" }, 12f, GREY), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                val copy = tv("Copy", 13f, ORANGE, true).apply { setPadding(12.dp(), 6.dp(), 12.dp(), 6.dp()) }
                copy.setOnClickListener {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code))
                    copy.text = "Copied ✓"
                    ui.postDelayed({ copy.text = "Copy" }, 1500)
                }
                addView(copy)
                addView(tv("Share", 13f, ORANGE, true).apply {
                    setPadding(12.dp(), 6.dp(), 12.dp(), 6.dp())
                    setOnClickListener {
                        startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Share code"))
                    }
                })
            }
            val body = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(TextView(this@MainActivity).apply {
                    this.text = code; textSize = 12.5f; typeface = Typeface.MONOSPACE
                    setTextColor(Color.parseColor("#EAEAEA")); setPadding(14.dp(), 4.dp(), 14.dp(), 14.dp())
                    setTextIsSelectable(true)
                })
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = pill(Color.parseColor("#0E0E0E"), 14).apply { setStroke(1.dp(), Color.parseColor("#33FF8C1E")) }
                addView(head); addView(body)
            }
            col.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
        }

        val fence = Regex("```([A-Za-z0-9+#._-]*)[ \\t]*\\n?([\\s\\S]*?)(```|$)")
        var pos = 0
        for (m in fence.findAll(text)) {
            addTextAndImages(text.substring(pos, m.range.first))
            addCode(m.groupValues[1], m.groupValues[2].trimEnd('\n'))
            pos = m.range.last + 1
        }
        if (pos < text.length) addTextAndImages(text.substring(pos))
        return col
    }

    private fun showReply(text: String) {
        val v = replyView(text)
        v.alpha = 0f; v.translationY = 18.dp().toFloat()
        list.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        v.animate().alpha(1f).translationY(0f).setDuration(350).start()
        empty.visibility = View.GONE
        scrollDown()
    }

    // =====================================================================
    //  sending
    // =====================================================================
    private fun looksLikeCode(q: String): Boolean {
        val l = q.lowercase().trim()
        if (Regex("^(open|launch|call|dial|text|message|play|navigate|scroll|swipe|next|previous|click|tap|go |read my|check my|remember|forget|set a|set an|turn|volume|take a|auto|stop)").containsMatchIn(l)) return false
        if (l.contains("```")) return true
        val verb = Regex("\\b(write|make|create|build|code|generate|develop|program|fix|debug|refactor|convert|implement|script|add)\\b")
        val noun = Regex("\\b(code|script|program|app|application|game|website|web page|webpage|function|class|bug|error|plugin|mod|bot|api|html|css|javascript|python|java|kotlin|lua|luau|c\\+\\+|c#|unity|godot|roblox|minecraft|react|node|sql|database|algorithm|android)\\b")
        return verb.containsMatchIn(l) && noun.containsMatchIn(l)
    }

    private fun turnsOf(msgs: List<Pair<Boolean, String>>): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var i = 0
        while (i < msgs.size - 1) {
            if (msgs[i].first && !msgs[i + 1].first) { out.add(msgs[i].second to msgs[i + 1].second); i += 2 } else i++
        }
        return out
    }

    private fun send(q0: String) {
        val q = q0.trim()
        if (q.isEmpty() || uiLocked) return
        if (Agent.busy) { Agent.cancel = true; note("Okay, stopping what I was doing…"); return }
        hideKeyboard()
        input.setText("")

        val pf = profile
        val cid = chatId
        Agent.history = turnsOf(Chats.load(this, pf, cid))
        val first = !hasMessages
        hasMessages = true
        userBubble(q)
        Chats.add(this, pf, cid, true, q)
        if (first) ringToHeader()
        scrollDown()

        val isImage = Agent.imagePrompt(q) != null
        val code = !isImage && (codeForced || looksLikeCode(q))
        setWorking(true, code)
        val steps = startSteps()
        Thread {
            val report: (String) -> Unit = { p -> runOnUiThread { progressNote = p; stepAdd(steps, p) } }
            val r = if (code) Agent.runCode(this, q, report) else Agent.run(this, q, report)
            val text = r.ifBlank { "Done." }
            Chats.add(this, pf, cid, false, text)
            runOnUiThread {
                setWorking(false, false)
                stepsDone(steps)
                if (pf == profile && cid == chatId && !uiLocked) showReply(text)
                if (Prefs.speak(this)) Speaker.say(this, r.replace(Regex("\\[\\[img:[^\\]]*\\]\\]"), ""))
                if (uiLocked && pf != "guest") { // the screen was locked while Kayron worked: close the account now
                    Vault.lock(pf); list.removeAllViews(); chatLoaded = false
                }
            }
        }.start()
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    // =====================================================================
    //  lock screen
    // =====================================================================
    private fun buildLock() {
        lockEmail = tv("", 14f, GREY).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, 16.dp()) }
        lockPw = EditText(this).apply {
            hint = "Password"
            setHintTextColor(Color.parseColor("#6E6E6E"))
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = pill(Color.parseColor("#151515"), 24).apply { setStroke(1.dp(), Color.parseColor("#44FF8C1E")) }
            setPadding(18.dp(), 12.dp(), 18.dp(), 12.dp())
            setOnEditorActionListener { _, _, _ -> tryUnlock(); true }
        }
        lockMsg = tv("", 13f, RED).apply { gravity = Gravity.CENTER; setPadding(0, 8.dp(), 0, 8.dp()) }
        lockBtn = tv("Unlock", 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp())
            background = brand(26)
            setOnClickListener { tryUnlock() }
        }
        val lockRing = RingView(this).apply { speed = 1.2f }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32.dp(), 0, 32.dp(), 0)
            addView(lockRing, LinearLayout.LayoutParams(150.dp(), 150.dp()))
            addView(tv("Kayron", 24f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
            addView(lockEmail, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(lockPw, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(lockMsg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(lockBtn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(tv("Forgot password?", 13f, ORANGE).apply {
                gravity = Gravity.CENTER; setPadding(0, 18.dp(), 0, 10.dp()); setOnClickListener { forgotDialog() }
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(tv("Use Guest instead", 13f, GREY).apply {
                gravity = Gravity.CENTER; setPadding(0, 6.dp(), 0, 6.dp()); setOnClickListener { leaveLock() }
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        lockView = FrameLayout(this).apply {
            setBackgroundColor(BG)
            isClickable = true
            visibility = View.GONE
            addView(col, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER))
        }
    }

    private fun showLock() {
        uiLocked = true
        hideKeyboard()
        lockEmail.text = "🔒  $profile"
        lockPw.setText("")
        lockMsg.text = ""
        lockView.visibility = View.VISIBLE
        applySecure()
        lockPw.requestFocus()
    }

    private fun tryUnlock() {
        val p = profile
        val pw = lockPw.text.toString().toCharArray()
        if (pw.isEmpty()) return
        lockBtn.isEnabled = false
        lockBtn.text = "Unlocking…"
        Thread {
            val r = Vault.unlock(this@MainActivity, p, pw)
            runOnUiThread {
                lockBtn.isEnabled = true
                lockBtn.text = "Unlock"
                if (p == profile) {
                    if (r.ok) {
                        unlocked()
                    } else {
                        lockPw.setText("")
                        lockMsg.text = if (r.waitSec > 0) "Too many tries. Wait ${r.waitSec} seconds." else "Wrong password."
                    }
                }
            }
        }.start()
    }

    /** The account is open: hide the lock screen and show the chats. */
    private fun unlocked() {
        uiLocked = false
        lockView.visibility = View.GONE
        hideKeyboard()
        if (!chatLoaded) { chooseChat(); loadChat(false) }
        refreshStatus()
        applySecure()
    }

    private fun maybeLock() {
        if (profile == "guest" || uiLocked || leftAt == 0L) return
        val ms = Prefs.autoLockMin(this) * 60_000L
        if (System.currentTimeMillis() - leftAt >= ms) lockNow()
    }

    private fun lockNow() {
        if (profile == "guest") return
        if (!Agent.busy) { Vault.lock(profile); list.removeAllViews(); chatLoaded = false }
        closeDrawer()
        showLock()
    }

    private fun leaveLock() {
        if (!Agent.busy) Vault.lock(profile)
        Prefs.setProfile(this, "guest")
        onProfileChanged()
    }

    /** Accounts hide their screen from screenshots and the recent-apps preview. */
    private fun applySecure() {
        if (profile != "guest" || uiLocked) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun forgotDialog() {
        val p = profile
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22.dp(), 12.dp(), 22.dp(), 0) }
        val code = EditText(this).apply {
            hint = "Recovery code"; setSingleLine(); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        val n1 = pwField("New password")
        val n2 = pwField("Repeat new password")
        val msg = tv("", 12f, RED)
        box.addView(tv("Enter the recovery code you saved when you made this account. Your chats stay.", 12f, Color.GRAY))
        box.addView(code); box.addView(n1); box.addView(n2); box.addView(msg)
        val d = AlertDialog.Builder(this).setTitle("Forgot password")
            .setView(box)
            .setPositiveButton("Reset", null)
            .setNeutralButton("Erase account", null)
            .setNegativeButton("Cancel", null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = n1.text.toString()
                val err = if (a != n2.text.toString()) "The two passwords are different." else Vault.weak(a, p)
                if (err != null) { msg.text = err; return@setOnClickListener }
                msg.text = "Working…"
                Thread {
                    val ok = Vault.unlockWithRecovery(this@MainActivity, p, code.text.toString(), a.toCharArray())
                    runOnUiThread {
                        if (ok) {
                            d.dismiss()
                            unlocked()
                            note("🔑 New password set. Your chats are safe.")
                        } else msg.text = "That recovery code is not right."
                    }
                }.start()
            }
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { d.dismiss(); eraseAccount(p) }
        }
        d.show()
    }

    // =====================================================================
    //  accounts: create, verify with Google, change password, delete
    // =====================================================================
    private fun createAccountDialog(prefill: String?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22.dp(), 12.dp(), 22.dp(), 0) }
        val email = EditText(this).apply {
            hint = "Gmail address"; setSingleLine(); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            if (prefill != null) { setText(prefill); isEnabled = false }
        }
        val pw = pwField("Password (8 or more characters)")
        val pw2 = pwField("Repeat password")
        val msg = tv("", 12f, RED)
        box.addView(tv(
            if (prefill == null) "Each account has its own password and its own private chats on this phone."
            else "Give this account a password. Its chats get locked with it.", 12f, Color.GRAY))
        box.addView(email); box.addView(pw); box.addView(pw2); box.addView(msg)
        val d = AlertDialog.Builder(this)
            .setTitle(if (prefill == null) "Create account" else "Set a password")
            .setView(box)
            .setPositiveButton("Create", null)
            .setNegativeButton("Cancel", null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val e = email.text.toString().trim().lowercase()
                val a = pw.text.toString()
                val err = when {
                    !Regex("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$").matches(e) -> "Enter a valid email address."
                    prefill == null && Prefs.profiles(this@MainActivity).contains(e) -> "That account is already on this phone. Open it from the list."
                    a != pw2.text.toString() -> "The two passwords are different."
                    else -> Vault.weak(a, e)
                }
                if (err != null) { msg.text = err; return@setOnClickListener }
                msg.text = "Creating…"
                d.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                Thread {
                    val recovery = Vault.create(this@MainActivity, e, a.toCharArray())
                    Chats.protect(this@MainActivity, e)
                    runOnUiThread {
                        d.dismiss()
                        // the account that was open before gets closed
                        if (profile != "guest" && profile != e && !Agent.busy) Vault.lock(profile)
                        Prefs.addProfile(this@MainActivity, e)
                        Prefs.setProfile(this@MainActivity, e)
                        onProfileChanged()
                        showRecovery(recovery)
                    }
                }.start()
            }
        }
        d.show()
    }

    private fun showRecovery(code: String) {
        val d = AlertDialog.Builder(this)
            .setTitle("Save your recovery code")
            .setMessage("$code\n\nWrite it down or save it somewhere safe. If you forget your password, this code is the ONLY way to open your chats again. Kayron cannot show it a second time.")
            .setPositiveButton("I saved it", null)
            .setNeutralButton("Copy", null)
            .setCancelable(false)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("recovery", code))
                Toast.makeText(this, "Copied. Paste it somewhere safe.", Toast.LENGTH_SHORT).show()
            }
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                d.dismiss()
                note("🔒 Account ready. Your chats are encrypted with your password. Open Settings > Account security > Verify with Google to turn on Gmail.")
            }
        }
        d.show()
    }

    private fun verifyGoogle(p: String) {
        verifyFor = p
        val cl = GoogleSignIn.getClient(this, GmailApi.options(p))
        cl.signOut().addOnCompleteListener { startActivityForResult(cl.signInIntent, 9) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 9) {
            val p = verifyFor
            verifyFor = null
            GoogleSignIn.getSignedInAccountFromIntent(d)
                .addOnSuccessListener { acc ->
                    val email = (acc.email ?: "").lowercase()
                    if (p != null && email == p) {
                        Vault.setVerified(this, p, true)
                        refreshStatus()
                        note("✅ $p is verified with Google. Gmail features are on for this account.")
                    } else {
                        GoogleSignIn.getClient(this, GmailApi.options()).signOut()
                        note("😕 That Google account ($email) is not ${p ?: "the one you picked"}. Nothing changed.")
                    }
                }
                .addOnFailureListener { note("Google sign-in failed: ${it.message}. See the README, Gmail step.") }
        }
    }

    private fun changePasswordDialog(p: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22.dp(), 12.dp(), 22.dp(), 0) }
        val old = pwField("Current password")
        val n1 = pwField("New password")
        val n2 = pwField("Repeat new password")
        val msg = tv("", 12f, RED)
        box.addView(old); box.addView(n1); box.addView(n2); box.addView(msg)
        val d = AlertDialog.Builder(this).setTitle("Change password").setView(box)
            .setPositiveButton("Change", null).setNegativeButton("Cancel", null).create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = n1.text.toString()
                val err = if (a != n2.text.toString()) "The two new passwords are different." else Vault.weak(a, p)
                if (err != null) { msg.text = err; return@setOnClickListener }
                msg.text = "Working…"
                Thread {
                    val ok = Vault.changePassword(this@MainActivity, p, old.text.toString().toCharArray(), a.toCharArray())
                    runOnUiThread {
                        if (ok) { d.dismiss(); note("🔑 Password changed.") }
                        else msg.text = "The current password is wrong."
                    }
                }.start()
            }
        }
        d.show()
    }

    private fun eraseAccount(p: String) {
        AlertDialog.Builder(this).setTitle("Delete this account?")
            .setMessage("$p and ALL its chats, pictures and memory will be removed from this phone. This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> wipeAccount(p) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun wipeAccount(p: String) {
        Vault.delete(this, p)
        Chats.wipe(this, p)
        Memory.wipe(this, p)
        Images.wipe(this, p)
        Prefs.removeProfile(this, p)
        if (GoogleSignIn.getLastSignedInAccount(this)?.email?.lowercase() == p) {
            GoogleSignIn.getClient(this, GmailApi.options()).signOut()
        }
        if (profile == p) onProfileChanged()
        note("🗑 Account removed from this phone.")
    }

    private fun accountMenu(p: String) {
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (p == profile && !uiLocked) items.add("🔒  Lock now" to { lockNow() })
        items.add((if (Vault.verified(this, p)) "✔  Verified with Google (check again)" else "✔  Verify with Google (turns on Gmail)") to { verifyGoogle(p) })
        items.add("🔑  Change password" to { changePasswordDialog(p) })
        items.add("🗑  Delete account" to { eraseAccount(p) })
        AlertDialog.Builder(this).setTitle(p)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .setNegativeButton("Close", null).show()
    }

    private fun notice() {
        AlertDialog.Builder(this).setTitle("How Kayron's free AI works ✨")
            .setMessage("Kayron has a free AI built in, so you do not need any key.\n\n" +
                "Because it is an online service, what you type, and anything you ask Kayron to read (your screen, notifications or emails), is sent to it. " +
                "Do not ask it to read things you want to keep private.\n\n" +
                "Chats inside a password-protected account are encrypted on this phone.")
            .setPositiveButton("Got it") { _, _ -> Prefs.setNoticeShown(this, true) }
            .setCancelable(false).show()
    }

    // =====================================================================
    //  chats and accounts
    // =====================================================================
    /** Picks the chat to show for the current account (the last one used, or a fresh one). */
    private fun chooseChat() {
        val saved = Prefs.activeChat(this, profile)
        val all = Chats.list(this, profile)
        chatId = when {
            all.any { it.id == saved } -> saved
            all.isNotEmpty() -> all.first().id
            else -> Chats.create(this, profile)
        }
        Prefs.setActiveChat(this, profile, chatId)
    }

    private fun loadChat(animate: Boolean) {
        list.removeAllViews()
        chatLoaded = true
        val msgs = Chats.load(this, profile, chatId)
        hasMessages = msgs.isNotEmpty()
        for ((isUser, t) in msgs) if (isUser) userBubble(t) else list.addView(replyView(t), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        if (hasMessages) {
            empty.visibility = View.GONE
            if (animate && !ringAtHeader) ringToHeader() else { ringAtHeader = true; rootFrame.post { snapRing() } }
        } else {
            empty.visibility = View.VISIBLE; empty.alpha = 1f
            if (animate && ringAtHeader) ringToCenter() else { ringAtHeader = false; rootFrame.post { snapRing() } }
        }
        scrollDown()
    }

    private fun openChat(id: String) {
        chatId = id
        Prefs.setActiveChat(this, profile, id)
        loadChat(true)
        closeDrawer()
    }

    private fun newChat() {
        if (hasMessages) {
            chatId = Chats.create(this, profile)
            Prefs.setActiveChat(this, profile, chatId)
            loadChat(true)
        }
        closeDrawer()
    }

    /** Shows the right thing after the open account changed: the lock screen, or the account's chats. */
    private fun onProfileChanged() {
        profile = Prefs.profile(this)
        if (profile != "guest" && !Vault.exists(this, profile)) { Prefs.setProfile(this, "guest"); profile = "guest" }
        closeDrawer()
        if (!Vault.isUnlocked(profile)) {
            list.removeAllViews(); chatLoaded = false
            showLock()
        } else {
            uiLocked = false
            lockView.visibility = View.GONE
            chooseChat(); loadChat(true)
            refreshStatus()
        }
        applySecure()
    }

    private fun switchProfile(p: String) {
        if (p == profile) { closeDrawer(); return }
        if (p != "guest" && !Vault.exists(this, p)) { closeDrawer(); createAccountDialog(p); return }
        // leaving an account closes it, so nobody can open it by just switching
        if (profile != "guest" && !Agent.busy) Vault.lock(profile)
        Prefs.setProfile(this, p)
        onProfileChanged()
    }

    // ---------------------------------------------------------------- drawer
    private fun row(label: String, selected: Boolean = false, onClick: () -> Unit): TextView =
        tv(label, 15f, if (selected) ORANGE else Color.parseColor("#E6E6E6"), selected).apply {
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            if (selected) background = pill(Color.parseColor("#1F1409"), 12)
            maxLines = 1
            setOnClickListener { onClick() }
        }

    private fun refreshDrawer() {
        drawerBody.removeAllViews()
        fun add(v: View, top: Int = 2) = drawerBody.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = top.dp() })
        fun label(s: String) = add(tv(s, 11f, GREY, true).apply { setPadding(14.dp(), 14.dp(), 0, 4.dp()) })

        add(tv("Kayron", 22f, Color.WHITE, true).apply { setPadding(14.dp(), 14.dp(), 0, 4.dp()) })

        add(tv("＋  New chat", 15f, Color.WHITE, true).apply {
            setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp()); background = brand(14)
            setOnClickListener { newChat() }
        }, 10)

        label("ACCOUNT  (hold an account for options)")
        for (p in listOf("guest") + Prefs.profiles(this)) {
            val text = if (p == "guest") "👤  Guest" else
                "✉  $p" + (if (Vault.verified(this, p)) "  ✔" else "")
            add(row(text, p == profile) { switchProfile(p) }.apply {
                if (p != "guest") setOnLongClickListener { closeDrawer(); accountMenu(p); true }
            })
        }
        add(row("＋  Add Gmail account") { closeDrawer(); createAccountDialog(null) })

        label("CHATS")
        val chats = if (Vault.isUnlocked(profile)) Chats.list(this, profile) else emptyList()
        if (chats.isEmpty()) add(tv("No chats yet", 13f, GREY).apply { setPadding(14.dp(), 6.dp(), 0, 6.dp()) })
        for (m in chats) {
            add(row(m.title.ifBlank { "New chat" }, m.id == chatId) { openChat(m.id) }.apply {
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Delete this chat?")
                        .setMessage(m.title)
                        .setPositiveButton("Delete") { _, _ ->
                            Chats.delete(this@MainActivity, profile, m.id)
                            if (m.id == chatId) { chooseChat(); loadChat(true) }
                            refreshDrawer()
                        }.setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
    }

    private fun openDrawer() {
        if (drawerOpen || uiLocked) return
        drawerOpen = true
        hideKeyboard()
        refreshDrawer()
        scrim.visibility = View.VISIBLE; drawer.visibility = View.VISIBLE
        scrim.animate().alpha(1f).setDuration(220).start()
        drawer.animate().translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        scrim.animate().alpha(0f).setDuration(200).withEndAction { scrim.visibility = View.GONE }.start()
        drawer.animate().translationX(-drawerW.toFloat()).setDuration(220)
            .withEndAction { drawer.visibility = View.GONE }.start()
    }

    // =====================================================================
    //  setup and settings
    // =====================================================================
    private fun checklist() {
        fun open(i: Intent): () -> Unit = { startActivity(i) }
        val pkg = Uri.parse("package:$packageName")
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val rows: List<Triple<Boolean, String, () -> Unit>> = listOf(
            Triple(true, "AI: free and built in, no key needed (a Gemini key is optional)", { settings() }),
            Triple(KayronAccessibility.inst != null, "Accessibility: lets Kayron see the screen, tap, scroll",
                open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))),
            Triple(KayronNotifications.connected, "Notification access: read your notifications",
                open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))),
            Triple(contacts, "Contacts: call or text people by name",
                { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 1) }),
            Triple(GmailApi.account(this) != null, "Gmail: make an account, then verify it with Google",
                { if (profile == "guest") createAccountDialog(null) else verifyGoogle(profile) }),
            Triple(false, "If a switch is blocked: App info > ⋮ > Allow restricted settings",
                open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)))
        )
        AlertDialog.Builder(this).setTitle("Set up Kayron")
            .setItems(rows.map { (if (it.first) "✅ " else "⬜ ") + it.second }.toTypedArray()) { _, i -> rows[i].third() }
            .setNegativeButton("Done", null).show()
    }

    private fun settings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22.dp(), 12.dp(), 22.dp(), 0)
        }
        fun field(hint: String, value: String) = EditText(this).apply {
            this.hint = hint; setText(value); setSingleLine(); textSize = 14f
        }
        fun btn(label: String, run: () -> Unit) = tv(label, 14f).apply {
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            background = pill(Color.parseColor("#2A2A2A"))
            setOnClickListener { run() }
        }.also {
            box.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
        }

        // ---- account security ----
        box.addView(tv("Account", 12f, Color.GRAY))
        if (profile == "guest") {
            box.addView(tv("Guest chats are not protected by a password. Make an account to lock your chats.", 12f, Color.GRAY))
            btn("🔒 Create a protected account") { createAccountDialog(null) }
        } else {
            box.addView(tv(profile + (if (Vault.verified(this, profile)) "  (verified with Google)" else "  (not verified with Google yet)"), 12f, Color.GRAY))
            btn("🔒 Account security") { accountMenu(profile) }
            val lockBtn2 = btn("") { }
            fun lockText() {
                val m = Prefs.autoLockMin(this)
                lockBtn2.text = "Auto-lock: " + (if (m == 0) "as soon as you leave" else "after $m min away") + " (tap to change)"
            }
            lockText()
            lockBtn2.setOnClickListener {
                val opts = listOf(0, 1, 5, 15)
                Prefs.setAutoLockMin(this, opts[(opts.indexOf(Prefs.autoLockMin(this)) + 1) % opts.size])
                lockText()
            }
        }

        // ---- the AI ----
        val key = field("Gemini key (optional)", Prefs.key(this))
        val model = field("Chat model", Prefs.model(this))
        val codeModel = field("Code model", Prefs.codeModel(this))
        val limit = field("Daily limit of Gemini requests", Prefs.dailyLimit(this).toString())
        limit.inputType = InputType.TYPE_CLASS_NUMBER
        box.addView(tv("AI engine", 12f, Color.GRAY).apply { setPadding(0, 14.dp(), 0, 0) })
        box.addView(tv("Right now: ${Ai.engine(this)}. The free AI is built in and needs no key. A Gemini key (aistudio.google.com/apikey) is optional and only makes answers stronger.", 12f, Color.GRAY))
        box.addView(key)
        box.addView(tv("Gemini models (only used with your key)", 12f, Color.GRAY).apply { setPadding(0, 10.dp(), 0, 0) })
        box.addView(model); box.addView(codeModel)
        box.addView(tv("Daily Gemini limit (protects your free Gemini allowance)", 12f, Color.GRAY).apply { setPadding(0, 10.dp(), 0, 0) })
        box.addView(limit)

        btn("Get a free Gemini key (optional)") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }
        val speakBtn = btn("") { }
        fun speakText() { speakBtn.text = if (Prefs.speak(this)) "Read replies aloud: ON (tap to turn off)" else "Read replies aloud: OFF (tap to turn on)" }
        speakText()
        speakBtn.setOnClickListener { Prefs.setSpeak(this, !Prefs.speak(this)); speakText() }
        btn("Set up Kayron (checklist)") { checklist() }
        btn("Allow notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("What Kayron remembers") { memory() }

        AlertDialog.Builder(this).setTitle("Kayron settings")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                Prefs.setKey(this, key.text.toString())
                Prefs.setModel(this, model.text.toString())
                Prefs.setCodeModel(this, codeModel.text.toString())
                Prefs.setDailyLimit(this, limit.text.toString().toIntOrNull() ?: 200)
                refreshStatus()
                note("Saved.")
            }.setNegativeButton("Close", null).show()
    }

    private fun memory() {
        val f = Memory.facts(this)
        AlertDialog.Builder(this).setTitle("What Kayron remembers")
            .setMessage(if (f.isEmpty()) "Nothing yet. Tell Kayron: “remember that my name is …”" else f.joinToString("\n") { "• $it" })
            .setPositiveButton("Close", null)
            .setNegativeButton("Forget all") { _, _ -> Memory.forget(this, null); note("Memory cleared.") }
            .show()
    }
}
