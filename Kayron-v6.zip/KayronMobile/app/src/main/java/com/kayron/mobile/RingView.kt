package com.kayron.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.min

/** The Kayron ring: glowing orange loops that turn in space. Spins faster while Kayron is working. */
class RingView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sweep: Shader? = null
    private var ang = 0f
    private var last = 0L
    private var cur = 1f

    /** 1 = calm, about 3 = working, 5 = quick burst. */
    @Volatile var speed = 1f

    /** Thicker lines for small rings that are not scaled down from a big one (the little spinner in the chat). */
    @Volatile var strokeBoost = 1f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f; val cy = h / 2f
        sweep = SweepGradient(
            cx, cy,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#33FF7A1A"), Color.parseColor("#FFFF8C1E"),
                Color.parseColor("#FFFFD9A8"), Color.TRANSPARENT),
            floatArrayOf(0f, 0.25f, 0.62f, 0.78f, 1f)
        )
        core.shader = RadialGradient(cx, cy, min(w, h) * 0.5f, Color.argb(70, 255, 120, 20), Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }

    override fun onDraw(cv: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceIn(0f, 0.05f)
        last = now
        cur += (speed - cur) * 0.06f
        ang += dt * 55f * cur

        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val size = min(w, h)
        val r = size * 0.30f
        // when the ring is shrunk, keep the lines readable
        val thick = 1f + (1f - scaleX.coerceIn(0.1f, 1f)) * 1.8f
        val base = size * 0.010f * thick * strokeBoost

        cv.drawCircle(cx, cy, size * 0.5f, core)
        p.shader = sweep
        for (i in 0 until 6) {
            cv.save()
            cv.rotate(ang * (if (i % 2 == 0) 1f else -0.8f) + i * 30f, cx, cy)
            cv.scale(1f, 0.42f + 0.10f * i, cx, cy)
            p.strokeWidth = base * 5f; p.alpha = 22; cv.drawCircle(cx, cy, r, p)
            p.strokeWidth = base * 2.2f; p.alpha = 70; cv.drawCircle(cx, cy, r, p)
            p.strokeWidth = base; p.alpha = 255; cv.drawCircle(cx, cy, r, p)
            cv.restore()
        }
        postInvalidateOnAnimation()
    }
}
