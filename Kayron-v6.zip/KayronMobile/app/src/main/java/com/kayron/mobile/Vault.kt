package com.kayron.mobile

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Account security. Every Gmail account has its own password and its own secret data key.
 *
 *  - The data key (random, 256 bit) encrypts that account's chats, memory and pictures (AES-GCM).
 *  - The data key is stored wrapped twice: once by a key made from the password (PBKDF2), once by a
 *    key made from the recovery code. Neither the password nor the data key is ever saved.
 *  - Both wrapped copies are also sealed with a key that lives in the phone's secure hardware (Android Keystore),
 *    so the saved data is useless if it is copied off the phone.
 *  - Wrong passwords are slowed down: after 5 mistakes the account waits 30 s, then 60 s, 2 min ... up to 15 min.
 *  - Unlocked keys live in memory only. Closing the app, the auto-lock timer or switching account removes them.
 */
object Vault {
    private const val ITER = 200_000
    private const val HW_ALIAS = "kayron_vault_hw"
    private val MAGIC = byteArrayOf(0x4B, 0x59, 0x31) // "KY1" marks an encrypted file
    private val rnd = SecureRandom()
    private val keys = ConcurrentHashMap<String, ByteArray>()

    class Attempt(val ok: Boolean, val waitSec: Int = 0)

    private fun sp(c: Context) = c.getSharedPreferences("kayron_vault", Context.MODE_PRIVATE)
    private fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String?): ByteArray = Base64.decode(s ?: "", Base64.NO_WRAP)

    // ------------------------------------------------------------ crypto pieces
    private fun kdf(pw: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw, salt, ITER, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun seal(key: ByteArray, plain: ByteArray): ByteArray {
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return iv + ci.doFinal(plain)
    }

    /** Returns null when the key is wrong or the data was changed. */
    private fun open(key: ByteArray, data: ByteArray): ByteArray? {
        if (data.size < 12 + 16) return null
        return try {
            val ci = Cipher.getInstance("AES/GCM/NoPadding")
            ci.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, data, 0, 12))
            ci.doFinal(data, 12, data.size - 12)
        } catch (e: Exception) {
            null
        }
    }

    private fun hwKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(HW_ALIAS, null)
        if (existing is SecretKey) return existing
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(HW_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    /** Ties a blob to this phone's secure hardware. First byte: 1 = tied, 0 = stored plain (phone refused). */
    private fun hwWrap(plain: ByteArray): ByteArray = try {
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, hwKey())
        byteArrayOf(1) + ci.iv + ci.doFinal(plain)
    } catch (e: Exception) {
        byteArrayOf(0) + plain
    }

    private fun hwUnwrap(blob: ByteArray): ByteArray? {
        if (blob.isEmpty()) return null
        if (blob[0] == 0.toByte()) return blob.copyOfRange(1, blob.size)
        if (blob.size < 13 + 16) return null
        return try {
            val ci = Cipher.getInstance("AES/GCM/NoPadding")
            ci.init(Cipher.DECRYPT_MODE, hwKey(), GCMParameterSpec(128, blob, 1, 12))
            ci.doFinal(blob, 13, blob.size - 13)
        } catch (e: Exception) {
            null
        }
    }

    private fun unwrap(s: SharedPreferences, p: String, wrapName: String, saltName: String, secret: CharArray): ByteArray? {
        val blob = hwUnwrap(unb64(s.getString("$p.$wrapName", null))) ?: return null
        return open(kdf(secret, unb64(s.getString("$p.$saltName", null))), blob)
    }

    // ------------------------------------------------------------ state
    fun exists(c: Context, p: String): Boolean = sp(c).contains("$p.wrap")
    fun verified(c: Context, p: String): Boolean = sp(c).getBoolean("$p.ver", false)
    fun setVerified(c: Context, p: String, v: Boolean) { sp(c).edit().putBoolean("$p.ver", v).apply() }
    fun isUnlocked(p: String): Boolean = p == "guest" || keys.containsKey(p)
    fun lock(p: String) { keys.remove(p) }
    fun lockAll() { keys.clear() }

    // ------------------------------------------------------------ passwords
    /** Returns a message when the password is too weak, or null when it is fine. */
    fun weak(pw: String, email: String): String? {
        val name = email.substringBefore('@').lowercase()
        val common = setOf("password", "12345678", "123456789", "1234567890", "qwertyui", "11111111", "00000000", "iloveyou")
        return when {
            pw.length < 8 -> "Use at least 8 characters."
            pw.lowercase() in common -> "That password is too easy to guess."
            name.length >= 4 && pw.lowercase().contains(name) -> "Do not use your email name inside the password."
            pw.toSet().size < 4 -> "Use a mix of different characters."
            else -> null
        }
    }

    private fun newRecoveryCode(): String {
        val a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb = StringBuilder()
        for (i in 0 until 25) {
            if (i > 0 && i % 5 == 0) sb.append('-')
            sb.append(a[rnd.nextInt(a.length)])
        }
        return sb.toString()
    }

    private fun cleanCode(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    /** Makes the account's vault, unlocks it, and returns the recovery code (shown to the user once). */
    fun create(c: Context, p: String, pw: CharArray): String {
        val dk = ByteArray(32); rnd.nextBytes(dk)
        val salt = ByteArray(16); rnd.nextBytes(salt)
        val rsalt = ByteArray(16); rnd.nextBytes(rsalt)
        val code = newRecoveryCode()
        val wrap = hwWrap(seal(kdf(pw, salt), dk))
        val rwrap = hwWrap(seal(kdf(cleanCode(code).toCharArray(), rsalt), dk))
        sp(c).edit()
            .putString("$p.salt", b64(salt)).putString("$p.wrap", b64(wrap))
            .putString("$p.rsalt", b64(rsalt)).putString("$p.rwrap", b64(rwrap))
            .putInt("$p.fails", 0).putLong("$p.until", 0L)
            .apply()
        keys[p] = dk
        return code
    }

    fun unlock(c: Context, p: String, pw: CharArray): Attempt {
        val s = sp(c)
        val now = System.currentTimeMillis()
        val until = s.getLong("$p.until", 0L)
        if (until > now) return Attempt(false, ((until - now) / 1000 + 1).toInt())
        val dk = unwrap(s, p, "wrap", "salt", pw)
        if (dk != null) {
            s.edit().putInt("$p.fails", 0).putLong("$p.until", 0L).apply()
            keys[p] = dk
            return Attempt(true)
        }
        val fails = s.getInt("$p.fails", 0) + 1
        val wait = if (fails >= 5) minOf(900, 30 shl minOf(fails - 5, 5)) else 0
        s.edit().putInt("$p.fails", fails).putLong("$p.until", if (wait > 0) now + wait * 1000L else 0L).apply()
        return Attempt(false, wait)
    }

    private fun setPassword(c: Context, p: String, dk: ByteArray, newPw: CharArray) {
        val salt = ByteArray(16); rnd.nextBytes(salt)
        val wrap = hwWrap(seal(kdf(newPw, salt), dk))
        sp(c).edit().putString("$p.salt", b64(salt)).putString("$p.wrap", b64(wrap))
            .putInt("$p.fails", 0).putLong("$p.until", 0L).apply()
    }

    /** Forgot the password: the recovery code opens the vault and a new password is set. Chats stay. */
    fun unlockWithRecovery(c: Context, p: String, code: String, newPw: CharArray): Boolean {
        val dk = unwrap(sp(c), p, "rwrap", "rsalt", cleanCode(code).toCharArray()) ?: return false
        setPassword(c, p, dk, newPw)
        keys[p] = dk
        return true
    }

    fun changePassword(c: Context, p: String, oldPw: CharArray, newPw: CharArray): Boolean {
        val dk = unwrap(sp(c), p, "wrap", "salt", oldPw) ?: return false
        setPassword(c, p, dk, newPw)
        keys[p] = dk
        return true
    }

    fun delete(c: Context, p: String) {
        keys.remove(p)
        val e = sp(c).edit()
        for (k in listOf("salt", "wrap", "rsalt", "rwrap", "fails", "until", "ver")) e.remove("$p.$k")
        e.apply()
    }

    // ------------------------------------------------------------ files
    fun isEnc(d: ByteArray): Boolean = d.size > 3 && d[0] == MAGIC[0] && d[1] == MAGIC[1] && d[2] == MAGIC[2]

    /** Guest data is stored as it is. Account data is encrypted; throws if the account is locked. */
    fun enc(p: String, plain: ByteArray): ByteArray {
        if (p == "guest") return plain
        val k = keys[p] ?: throw IllegalStateException("locked")
        return MAGIC + seal(k, plain)
    }

    /** Null when the account is locked or the file was tampered with. */
    fun dec(p: String, data: ByteArray): ByteArray? {
        if (!isEnc(data)) return data
        val k = keys[p] ?: return null
        return open(k, data.copyOfRange(3, data.size))
    }
}
