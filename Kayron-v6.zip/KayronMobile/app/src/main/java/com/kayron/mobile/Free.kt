package com.kayron.mobile

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Kayron's own free AI. No key, no signup.
 *  - Text:     Pollinations (text.pollinations.ai), tries a few models in turn.
 *  - Pictures: Pollinations (image.pollinations.ai); if it is busy, the AI Horde community GPUs (anonymous).
 * These are free third-party services: they can be slow, change or rate-limit. If you add your own Gemini key
 * in settings, Kayron uses Gemini first and keeps this as the safety net.
 */
object Free {
    private const val UA = "KayronMobile/6.0"
    private val TEXT_MODELS = listOf("openai", "mistral", "llama")

    private class Res(val code: Int, val body: ByteArray, val type: String)

    private fun http(
        method: String, url: String, body: ByteArray? = null,
        headers: Map<String, String> = emptyMap(), readMs: Int = 60000
    ): Res {
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.requestMethod = method
            con.connectTimeout = 15000
            con.readTimeout = readMs
            con.setRequestProperty("User-Agent", UA)
            for ((k, v) in headers) con.setRequestProperty(k, v)
            if (body != null) {
                con.doOutput = true
                con.outputStream.use { it.write(body) }
            }
            val code = con.responseCode
            val st = if (code in 200..299) con.inputStream else con.errorStream
            val bytes = st?.use { it.readBytes() } ?: ByteArray(0)
            return Res(code, bytes, con.contentType ?: "")
        } finally {
            con.disconnect()
        }
    }

    // ---------------------------------------------------------------- text
    private fun extract(s: String): String = try {
        val o = JSONObject(s)
        when {
            o.has("choices") -> o.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: ""
            o.has("error") -> ""
            else -> s
        }
    } catch (e: Exception) {
        s
    }

    /** Some free tiers add an advert line at the end of the answer. Cut it off. */
    private fun clean(t0: String): String {
        var t = t0.trim()
        for (marker in listOf("Powered by Pollinations", "Support Pollinations")) {
            val i = t.indexOf(marker, ignoreCase = true)
            if (i >= 0) t = t.substring(0, i).trimEnd('-', '*', '_', ' ', '\n', '\r', '>')
        }
        return t.trim()
    }

    fun chat(
        system: String, history: List<Pair<String, String>>, user: String,
        imageB64: String? = null, json: Boolean = false
    ): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for ((u, k) in history.takeLast(6)) {
            msgs.put(JSONObject().put("role", "user").put("content", u.take(4000)))
            msgs.put(JSONObject().put("role", "assistant").put("content", k.take(6000)))
        }
        if (imageB64 != null) {
            val parts = JSONArray()
                .put(JSONObject().put("type", "text").put("text", user))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64")))
            msgs.put(JSONObject().put("role", "user").put("content", parts))
        } else {
            msgs.put(JSONObject().put("role", "user").put("content", user))
        }

        var net: IOException? = null
        for (round in 0..1) {
            for (m in TEXT_MODELS) {
                try {
                    val body = JSONObject().put("model", m).put("messages", msgs).put("temperature", 0.4).put("private", true)
                    if (json) body.put("jsonMode", true)
                    val r = http(
                        "POST", "https://text.pollinations.ai/openai",
                        body.toString().toByteArray(Charsets.UTF_8), mapOf("Content-Type" to "application/json"), 90000
                    )
                    if (r.code in 200..299) {
                        val t = clean(extract(String(r.body, Charsets.UTF_8)))
                        if (t.isNotBlank()) return t
                    }
                } catch (e: IOException) {
                    net = e
                }
            }
            if (round == 0) try { Thread.sleep(2500) } catch (e: InterruptedException) {}
        }
        if (net != null) throw net
        throw GeminiError("The free AI is busy right now. Please try again in a moment.")
    }

    // ---------------------------------------------------------------- pictures
    private fun valid(b: ByteArray): Boolean {
        if (b.size < 2000) return false
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        return o.outWidth > 0 && o.outHeight > 0
    }

    /** Paints a picture from words. Returns the image bytes, or null if every free service failed. */
    fun image(prompt: String, w: Int = 1024, h: Int = 1024, onStep: (String) -> Unit = {}): ByteArray? {
        val p = prompt.trim().take(600)
        val enc = URLEncoder.encode(p, "UTF-8").replace("+", "%20")
        for (model in listOf("flux", "")) {
            try {
                val seed = (Math.random() * 1_000_000).toInt()
                val url = "https://image.pollinations.ai/prompt/$enc?width=$w&height=$h&nologo=true&private=true&seed=$seed" +
                    (if (model.isEmpty()) "" else "&model=$model")
                val r = http("GET", url, null, emptyMap(), 120000)
                if (r.code in 200..299 && r.type.startsWith("image") && valid(r.body)) return r.body
            } catch (e: Exception) {
            }
        }
        onStep("The main painter is busy, trying the community GPUs")
        return horde(p, onStep)
    }

    /** AI Horde: volunteers' GPUs, free with the public anonymous key. Can queue for a while. */
    private fun horde(prompt: String, onStep: (String) -> Unit): ByteArray? {
        val h = mapOf("apikey" to "0000000000", "Client-Agent" to "kayron:6:anonymous", "Content-Type" to "application/json")
        return try {
            val params = JSONObject().put("width", 512).put("height", 512).put("steps", 25).put("n", 1)
                .put("sampler_name", "k_euler").put("cfg_scale", 7)
            val req = JSONObject().put("prompt", prompt).put("params", params)
                .put("nsfw", false).put("censor_nsfw", true).put("r2", true)
            val r = http("POST", "https://aihorde.net/api/v2/generate/async", req.toString().toByteArray(Charsets.UTF_8), h, 30000)
            if (r.code !in 200..299) return null
            val id = JSONObject(String(r.body, Charsets.UTF_8)).optString("id")
            if (id.isBlank()) return null

            val end = System.currentTimeMillis() + 180_000
            while (System.currentTimeMillis() < end) {
                Thread.sleep(4000)
                val s = http("GET", "https://aihorde.net/api/v2/generate/check/$id", null, h, 20000)
                val o = JSONObject(String(s.body, Charsets.UTF_8))
                if (o.optBoolean("faulted")) return null
                if (o.optBoolean("done")) break
                val q = o.optInt("queue_position", 0)
                onStep(if (q > 0) "In the queue, place $q" else "Painting")
            }
            val f = http("GET", "https://aihorde.net/api/v2/generate/status/$id", null, h, 30000)
            val gens = JSONObject(String(f.body, Charsets.UTF_8)).optJSONArray("generations") ?: return null
            val img = gens.optJSONObject(0)?.optString("img") ?: return null
            val bytes = if (img.startsWith("http")) http("GET", img, null, emptyMap(), 60000).body
            else Base64.decode(img, Base64.DEFAULT)
            if (valid(bytes)) bytes else null
        } catch (e: Exception) {
            null
        }
    }
}

/** One door for all AI calls: your Gemini key first (if you added one), otherwise the free built-in AI. */
object Ai {
    private fun hasKey(c: Context) = Prefs.key(c).isNotBlank()
    private fun gemOk(c: Context) = hasKey(c) && Usage.today(c) < Prefs.dailyLimit(c)

    fun engine(c: Context): String = if (hasKey(c)) "Gemini (your key)" else "Free AI"

    /** One agent step (JSON reply), optionally with a screenshot. */
    fun ask(c: Context, system: String, prompt: String, imageB64: String?): String {
        if (gemOk(c)) {
            try { return Gemini.ask(c, system, prompt, imageB64) } catch (e: Exception) { /* fall back to the free AI */ }
        }
        return Free.chat(system, emptyList(), prompt, imageB64, true)
    }

    fun code(c: Context, system: String, history: List<Pair<String, String>>, user: String): String {
        if (gemOk(c)) {
            try { return Gemini.code(c, system, history, user) } catch (e: Exception) { /* fall back to the free AI */ }
        }
        return Free.chat(system, history, user)
    }

    fun review(c: Context, system: String, request: String, draft: String): String {
        if (gemOk(c)) {
            try { return Gemini.review(c, system, request, draft) } catch (e: Exception) { /* fall back to the free AI */ }
        }
        return Free.chat(system, emptyList(), "REQUEST:\n$request\n\nANSWER TO REVIEW:\n$draft")
    }
}
