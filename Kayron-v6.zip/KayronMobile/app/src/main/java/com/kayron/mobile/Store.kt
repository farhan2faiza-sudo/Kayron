package com.kayron.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A safe folder / file name for an account (its email). */
internal fun safeName(p: String): String = p.lowercase().replace(Regex("[^a-z0-9@._-]"), "_")

/** Settings. Stored privately on the phone. The Gemini key is OPTIONAL: Kayron has a free built-in AI. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("kayron", Context.MODE_PRIVATE)

    /** OPTIONAL: paste your Gemini key between the quotes to build it into the app. */
    private const val BUILT_IN_KEY = ""

    fun key(c: Context): String = (sp(c).getString("key", "") ?: "").ifBlank { BUILT_IN_KEY }
    fun setKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()
    const val DEFAULT_MODEL = "gemini-3.5-flash"

    /** Old saved names (Gemini 1 and 2 are shut down) are replaced by the current default. */
    fun model(c: Context): String {
        val m = (sp(c).getString("model", "") ?: "").trim()
        return if (m.isBlank() || m.startsWith("gemini-1") || m.startsWith("gemini-2")) DEFAULT_MODEL else m
    }
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    /** Your own cap on Gemini requests per day (only used when you add your own Gemini key). */
    fun dailyLimit(c: Context): Int = sp(c).getInt("daily", 200)
    fun setDailyLimit(c: Context, v: Int) = sp(c).edit().putInt("daily", v.coerceIn(10, 5000)).apply()

    /** The model used for writing code. Put a stronger one here if your key allows it. */
    fun codeModel(c: Context): String =
        (sp(c).getString("codemodel", "") ?: "").trim().ifBlank { "gemini-3.6-flash" }
    fun setCodeModel(c: Context, v: String) = sp(c).edit().putString("codemodel", v.trim()).apply()

    // ---- accounts: "guest" or a Gmail address. Every account has its own password, chats and memory ----
    fun profiles(c: Context): List<String> =
        (sp(c).getString("profiles", "") ?: "").split("|").filter { it.isNotBlank() }

    fun profile(c: Context): String {
        val p = sp(c).getString("profile", "guest") ?: "guest"
        return if (p == "guest" || profiles(c).contains(p)) p else "guest"
    }
    fun setProfile(c: Context, v: String) = sp(c).edit().putString("profile", v).apply()

    fun addProfile(c: Context, email: String) {
        val all = (profiles(c) + email.lowercase()).distinct()
        sp(c).edit().putString("profiles", all.joinToString("|")).apply()
    }

    fun removeProfile(c: Context, email: String) {
        val all = profiles(c).filter { it != email.lowercase() }
        val e = sp(c).edit().putString("profiles", all.joinToString("|")).remove("active_$email")
        if (sp(c).getString("profile", "guest") == email) e.putString("profile", "guest")
        e.apply()
    }

    fun activeChat(c: Context, profile: String): String = sp(c).getString("active_$profile", "") ?: ""
    fun setActiveChat(c: Context, profile: String, id: String) = sp(c).edit().putString("active_$profile", id).apply()

    fun speak(c: Context): Boolean = sp(c).getBoolean("speak", false)
    fun setSpeak(c: Context, v: Boolean) = sp(c).edit().putBoolean("speak", v).apply()

    /** Minutes in the background before an account locks again. 0 = as soon as you leave the app. */
    fun autoLockMin(c: Context): Int = sp(c).getInt("autolock", 1)
    fun setAutoLockMin(c: Context, v: Int) = sp(c).edit().putInt("autolock", v).apply()

    fun noticeShown(c: Context): Boolean = sp(c).getBoolean("notice", false)
    fun setNoticeShown(c: Context, v: Boolean) = sp(c).edit().putBoolean("notice", v).apply()

    fun lockOn(c: Context): Boolean = sp(c).getBoolean("lock", false)
    fun setLockOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("lock", v).apply()
    fun picoKey(c: Context): String = sp(c).getString("pico", "") ?: ""
    fun setPicoKey(c: Context, v: String) = sp(c).edit().putString("pico", v.trim()).apply()
}

/** Kayron's long-term memory for the open account: lasting facts about you + the recent conversation. */
object Memory {
    private fun who(c: Context) = Prefs.profile(c)

    private fun file(c: Context, p: String) =
        if (p == "guest") File(c.filesDir, "memory.json") else File(c.filesDir, "memory_${safeName(p)}.json")

    private fun empty() = JSONObject().put("facts", JSONArray()).put("turns", JSONArray())

    private fun load(c: Context): JSONObject {
        val p = who(c)
        return try {
            val raw = Vault.dec(p, file(c, p).readBytes())
            if (raw == null) empty() else JSONObject(raw.toString(Charsets.UTF_8))
        } catch (e: Exception) {
            empty()
        }
    }

    private fun save(c: Context, o: JSONObject) {
        val p = who(c)
        try {
            file(c, p).writeBytes(Vault.enc(p, o.toString().toByteArray(Charsets.UTF_8)))
        } catch (e: Exception) {
            // locked account: nothing is written
        }
    }

    fun wipe(c: Context, p: String) { file(c, p).delete() }

    fun protect(c: Context, p: String) {
        if (p == "guest") return
        try {
            val f = file(c, p)
            if (!f.exists()) return
            val b = f.readBytes()
            if (!Vault.isEnc(b)) f.writeBytes(Vault.enc(p, b))
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun facts(c: Context): List<String> {
        val a = load(c).getJSONArray("facts")
        return List(a.length()) { a.getString(it) }
    }

    @Synchronized
    fun addFact(c: Context, fact: String): Boolean {
        val f = fact.trim()
        if (f.isEmpty()) return false
        val o = load(c)
        val a = o.getJSONArray("facts")
        for (i in 0 until a.length()) if (a.getString(i).equals(f, ignoreCase = true)) return false
        a.put(f)
        val keep = JSONArray()
        val from = maxOf(0, a.length() - 200) // keep the newest 200
        for (i in from until a.length()) keep.put(a.getString(i))
        o.put("facts", keep); save(c, o)
        return true
    }

    /** query == null forgets everything; otherwise forgets facts containing the words. Returns how many. */
    @Synchronized
    fun forget(c: Context, query: String?): Int {
        val o = load(c)
        val a = o.getJSONArray("facts")
        val keep = JSONArray()
        var n = 0
        for (i in 0 until a.length()) {
            val s = a.getString(i)
            if (query == null || s.lowercase().contains(query.lowercase().trim())) n++ else keep.put(s)
        }
        o.put("facts", keep)
        if (query == null) o.put("turns", JSONArray())
        save(c, o)
        return n
    }

    @Synchronized
    fun clearTurns(c: Context) { val o = load(c); o.put("turns", JSONArray()); save(c, o) }

    @Synchronized
    fun addTurn(c: Context, user: String, kayron: String) {
        val o = load(c)
        val a = o.getJSONArray("turns")
        a.put(JSONObject().put("u", user.take(300)).put("k", kayron.take(300)))
        val keep = JSONArray()
        for (i in maxOf(0, a.length() - 30) until a.length()) keep.put(a.getJSONObject(i))
        o.put("turns", keep); save(c, o)
    }

    @Synchronized
    fun turns(c: Context, n: Int): List<Pair<String, String>> {
        val a = load(c).getJSONArray("turns")
        return (maxOf(0, a.length() - n) until a.length()).map {
            a.getJSONObject(it).let { t -> t.getString("u") to t.getString("k") }
        }
    }
}

/** Counts today's Gemini requests (only when you use your own Gemini key). Resets by itself every day. */
object Usage {
    private fun sp(c: Context) = c.getSharedPreferences("kayron_usage", Context.MODE_PRIVATE)
    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun today(c: Context): Int {
        val s = sp(c)
        return if (s.getString("day", "") == day()) s.getInt("n", 0) else 0
    }

    fun add(c: Context) {
        val n = today(c) + 1
        sp(c).edit().putString("day", day()).putInt("n", n).apply()
    }
}

/** Pictures Kayron painted. Encrypted for accounts, plain for Guest. */
object Images {
    private fun dir(c: Context, p: String): File {
        val d = File(c.filesDir, "images/" + safeName(p))
        d.mkdirs(); return d
    }

    fun save(c: Context, p: String, bytes: ByteArray): String {
        val name = "img_" + System.currentTimeMillis() + ".kimg"
        File(dir(c, p), name).writeBytes(Vault.enc(p, bytes))
        return name
    }

    fun load(c: Context, p: String, name: String): ByteArray? {
        if (name.contains("..")) return null
        return try {
            Vault.dec(p, File(dir(c, p), name).readBytes())
        } catch (e: Exception) {
            null
        }
    }

    fun wipe(c: Context, p: String) { dir(c, p).deleteRecursively() }
}

/** Many chats per account, kept on the phone. Each account (Guest or a Gmail) has its own list, encrypted. */
object Chats {
    class Meta(val id: String, val title: String, val updated: Long)

    private fun dir(c: Context, p: String): File {
        val d = File(c.filesDir, "chats/" + safeName(p))
        d.mkdirs(); return d
    }
    private fun file(c: Context, p: String, id: String) = File(dir(c, p), "$id.json")
    private fun idx(c: Context, p: String) = File(dir(c, p), "index.json")

    /** Null when the file is missing, unreadable, or the account is locked. */
    private fun readArr(f: File, p: String): JSONArray? = try {
        val d = Vault.dec(p, f.readBytes())
        if (d == null) null else JSONArray(d.toString(Charsets.UTF_8))
    } catch (e: Exception) {
        null
    }

    /** Throws if the account is locked, so a locked account can never overwrite anything. */
    private fun writeArr(f: File, p: String, a: JSONArray) {
        f.writeBytes(Vault.enc(p, a.toString().toByteArray(Charsets.UTF_8)))
    }

    private fun readIdx(c: Context, p: String): MutableList<Meta> {
        val a = readArr(idx(c, p), p) ?: return mutableListOf()
        return try {
            MutableList(a.length()) { a.getJSONObject(it).let { o -> Meta(o.getString("id"), o.getString("t"), o.getLong("u")) } }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun writeIdx(c: Context, p: String, list: List<Meta>) {
        val a = JSONArray()
        for (m in list) a.put(JSONObject().put("id", m.id).put("t", m.title).put("u", m.updated))
        writeArr(idx(c, p), p, a)
    }

    @Synchronized
    fun list(c: Context, p: String): List<Meta> = readIdx(c, p).sortedByDescending { it.updated }

    @Synchronized
    fun create(c: Context, p: String): String {
        val id = System.currentTimeMillis().toString()
        writeArr(file(c, p, id), p, JSONArray())
        val l = readIdx(c, p); l.add(Meta(id, "New chat", System.currentTimeMillis())); writeIdx(c, p, l)
        return id
    }

    @Synchronized
    fun load(c: Context, p: String, id: String): List<Pair<Boolean, String>> {
        val a = readArr(file(c, p, id), p) ?: return emptyList()
        return try {
            List(a.length()) { a.getJSONObject(it).let { o -> o.getBoolean("u") to o.getString("t") } }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun add(c: Context, p: String, id: String, user: Boolean, text: String) {
        try {
            val a = readArr(file(c, p, id), p) ?: JSONArray()
            a.put(JSONObject().put("u", user).put("t", text.take(40000)))
            val keep = JSONArray()
            for (i in maxOf(0, a.length() - 200) until a.length()) keep.put(a.getJSONObject(i))
            writeArr(file(c, p, id), p, keep)
            val l = readIdx(c, p)
            val i = l.indexOfFirst { it.id == id }
            if (i >= 0) {
                val old = l[i]
                val title = if (old.title == "New chat" && user) text.trim().replace("\n", " ").take(40) else old.title
                l[i] = Meta(id, title, System.currentTimeMillis())
                writeIdx(c, p, l)
            }
        } catch (e: Exception) {
            // locked account: nothing is written
        }
    }

    @Synchronized
    fun delete(c: Context, p: String, id: String) {
        try {
            file(c, p, id).delete()
            writeIdx(c, p, readIdx(c, p).filter { it.id != id })
        } catch (e: Exception) {
        }
    }

    /** Encrypts chats an older Kayron version saved in plain text, the moment an account gets a password. */
    @Synchronized
    fun protect(c: Context, p: String) {
        if (p == "guest") return
        dir(c, p).listFiles()?.forEach { f ->
            try {
                val b = f.readBytes()
                if (!Vault.isEnc(b)) f.writeBytes(Vault.enc(p, b))
            } catch (e: Exception) {
            }
        }
        Memory.protect(c, p)
    }

    /** Removes everything of one account from the phone. */
    @Synchronized
    fun wipe(c: Context, p: String) { dir(c, p).deleteRecursively() }
}
