package com.kayron.mobile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import kotlin.math.abs

/** Kayron: a chat that writes code, answers anything and controls your phone. Orange and black. */
class MainActivity : Activity() {
    private val BG = Color.parseColor("#0A0A0A")
    private val ORANGE = Color.parseColor("#FF8C1E")
    private val GREY = Color.parseColor("#8A8A8A")

    private lateinit var rootFrame: FrameLayout
    private lateinit var column: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var empty: LinearLayout
    private lateinit var ring: RingView
    private lateinit var ringSlot: View
    private lateinit var ringHome: View
    private lateinit var drawer: LinearLayout
    private lateinit var drawerBody: LinearLayout
    private lateinit var scrim: View
    private lateinit var codeBtn: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val RING = 200
    private var drawerOpen = false
    private var drawerW = 0
    private var ringAtHeader = false
    private var ringAnimating = false
    private var codeForced = false
    private var working = false
    private var workCode = false
    private var workStart = 0L
    private var progressNote = ""
    private var statusJob: Runnable? = null
    private var hasMessages = false
    private var downX = 0f
    private var downY = 0f
    private lateinit var profile: String
    private var lockLayer: View? = null
    private var skipLock = false
    private var pendingReset: String? = null
    private var stepsBox: LinearLayout? = null
    private val stepViews = ArrayList<TextView>()
    private var phaseLogged = false
    private lateinit var chatId: String

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    private fun pill(bg: Int, r: Int = 14) = GradientDrawable().apply {
        setColor(bg); cornerRadius = r.dp().toFloat()
    }

    private fun brand(r: Int) = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.parseColor("#FF9A2E"), Color.parseColor("#FF5A1A"))
    ).apply { cornerRadius = r.dp().toFloat() }

    private fun tv(s: String, sz: Float, col: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sz; setTextColor(col)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    // =====================================================================
    //  screen
    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        drawerW = (resources.displayMetrics.widthPixels * 0.82f).toInt()

        rootFrame = FrameLayout(this).apply { setBackgroundColor(BG) }
        column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rootFrame.addView(column, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // ---- header: ring (top left) + name + what Kayron is doing ----
        ringSlot = View(this)
        status = tv("", 12f, GREY)
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Kayron", 18f, Color.WHITE, true))
            addView(status)
        }
        column.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ringSlot, LinearLayout.LayoutParams(44.dp(), 44.dp()).apply { rightMargin = 12.dp() })
            addView(names)
            addView(View(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(tv("\u2630", 22f).apply {
                setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp()); setOnClickListener { openDrawer() }
            })
            addView(tv("\u2699", 24f).apply {
                setPadding(8.dp(), 8.dp(), 4.dp(), 8.dp()); setOnClickListener { settings() }
            })
        })

        // ---- messages + the start screen ----
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8.dp(), 0, 16.dp())
        }
        scroll = ScrollView(this).apply { addView(list) }

        ringHome = View(this)
        empty = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(ringHome, LinearLayout.LayoutParams(RING.dp(), RING.dp()))
            addView(tv("I can write code, answer anything and run your phone", 12f, ORANGE).apply {
                gravity = Gravity.CENTER; setPadding(12.dp(), 0, 12.dp(), 6.dp())
            })
            addView(tv("What Can I Do for You Today?", 26f, Color.parseColor("#FFD2A0"), true).apply {
                gravity = Gravity.CENTER; setPadding(12.dp(), 0, 12.dp(), 12.dp())
            })
            for (q in listOf("Build me a Snake game in HTML", "Read my notifications", "\u26A1 Set up Kayron")) {
                addView(tv(q, 14f, Color.parseColor("#CCCCCC")).apply {
                    setPadding(16.dp(), 10.dp(), 16.dp(), 10.dp())
                    background = pill(Color.parseColor("#151515"), 20)
                    setOnClickListener { if (q.startsWith("\u26A1")) checklist() else send(q) }
                }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
            }
        }
        val frame = FrameLayout(this).apply {
            addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(empty, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER))
        }
        column.addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // ---- the search / message widget ----
        input = EditText(this).apply {
            hint = "Search or ask Kayron\u2026"
            setHintTextColor(Color.parseColor("#6E6E6E"))
            setTextColor(Color.WHITE)
            textSize = 16f
            background = null
            maxLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        codeBtn = tv("</>", 14f, GREY, true).apply {
            setPadding(10.dp(), 6.dp(), 10.dp(), 6.dp())
            setOnClickListener {
                codeForced = !codeForced
                setTextColor(if (codeForced) ORANGE else GREY)
                note(if (codeForced) "Code mode is ON. Every message will be treated as a coding job." else "Code mode is OFF. Kayron decides by itself.")
            }
        }
        val go = tv("\u27A4", 22f, ORANGE).apply {
            setPadding(8.dp(), 6.dp(), 6.dp(), 6.dp()); setOnClickListener { send(input.text.toString()) }
        }
        column.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp(), 4.dp(), 10.dp(), 4.dp())
            background = pill(Color.parseColor("#121212"), 28).apply { setStroke(1.dp(), Color.parseColor("#44FF8C1E")) }
            addView(tv("\uD83D\uDD0D", 16f).apply { setPadding(0, 0, 8.dp(), 0) })
            addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(codeBtn); addView(go)
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })

        // ---- the ring (one view that travels between the middle and the top left) ----
        ring = RingView(this).apply { pivotX = 0f; pivotY = 0f }
        rootFrame.addView(ring, FrameLayout.LayoutParams(RING.dp(), RING.dp()))

        // ---- chats drawer ----
        scrim = View(this).apply {
            setBackgroundColor(Color.parseColor("#99000000")); visibility = View.GONE; alpha = 0f
            setOnClickListener { closeDrawer() }
        }
        rootFrame.addView(scrim, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        drawerBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14.dp(), 6.dp(), 14.dp(), 14.dp()) }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F0F10"))
            visibility = View.GONE
            translationX = -drawerW.toFloat()
            addView(ScrollView(this@MainActivity).apply { addView(drawerBody) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(tv("\u2699  Settings", 15f, Color.parseColor("#DDDDDD")).apply {
                setPadding(22.dp(), 16.dp(), 22.dp(), 16.dp()); setOnClickListener { closeDrawer(); settings() }
            })
        }
        rootFrame.addView(drawer, FrameLayout.LayoutParams(drawerW, MATCH_PARENT))

        rootFrame.setOnApplyWindowInsetsListener { _, ins -> // stay clear of the bars and the keyboard
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            column.setPadding(16.dp(), i.top + 10.dp(), 16.dp(), i.bottom + 10.dp())
            drawer.setPadding(0, i.top, 0, i.bottom)
            ins
        }
        rootFrame.viewTreeObserver.addOnGlobalLayoutListener { if (!ringAnimating) snapRing() }

        setContentView(rootFrame)

        profile = Prefs.profile(this)
        if (needsUnlock(profile)) showLock(profile) else startProfileUi()
        if (intent.getBooleanExtra("setup", false)) checklist()
    }

    override fun onResume() { super.onResume(); if (lockLayer == null) refreshStatus() }

    /** Lock a protected account again when you have been away from the app for a little while. */
    override fun onStop() { super.onStop(); Auth.leftAt = System.currentTimeMillis() }

    override fun onStart() {
        super.onStart()
        if (skipLock) { skipLock = false; return }
        if (profile != "guest" && Auth.isUnlocked(profile) && Auth.leftAt > 0 &&
            System.currentTimeMillis() - Auth.leftAt > 20_000) lockNow()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (i.getBooleanExtra("setup", false)) checklist()
    }

    override fun onBackPressed() { if (drawerOpen) closeDrawer() else super.onBackPressed() }

    /** Swipe right to open your chats, swipe left to close them. */
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (lockLayer != null) return super.dispatchTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                val w = resources.displayMetrics.widthPixels
                if (!drawerOpen && dx > 110.dp() && abs(dy) < 70.dp() && downX < w * 0.45f) openDrawer()
                else if (drawerOpen && dx < -110.dp() && abs(dy) < 90.dp()) closeDrawer()
            }
        }
        return super.dispatchTouchEvent(e)
    }

    // =====================================================================
    //  the ring
    // =====================================================================
    private fun posIn(v: View): Pair<Float, Float> {
        val a = IntArray(2); val r = IntArray(2)
        v.getLocationInWindow(a); rootFrame.getLocationInWindow(r)
        return Pair((a[0] - r[0]).toFloat(), (a[1] - r[1]).toFloat())
    }

    private fun smallScale() = 44.dp().toFloat() / RING.dp()

    /** Put the ring exactly where it belongs, with no animation. */
    private fun snapRing() {
        val target = if (ringAtHeader) ringSlot else ringHome
        if (target.width == 0) return
        val (x, y) = posIn(target)
        val s = if (ringAtHeader) smallScale() else 1f
        ring.x = x; ring.y = y; ring.scaleX = s; ring.scaleY = s
    }

    /** Big ring in the middle shrinks and flies to the top left while spinning fast. */
    private fun ringToHeader() {
        ringAtHeader = true
        val (x, y) = posIn(ringSlot)
        ringAnimating = true
        ring.speed = 5f
        ring.animate().x(x).y(y).scaleX(smallScale()).scaleY(smallScale())
            .setDuration(900).setInterpolator(DecelerateInterpolator(1.6f))
            .withEndAction { ringAnimating = false; applyRingSpeed(); snapRing() }.start()
        empty.animate().alpha(0f).setDuration(350)
            .withEndAction { empty.visibility = View.GONE; empty.alpha = 1f }.start()
    }

    private fun ringToCenter() {
        ringAtHeader = false
        empty.alpha = 0f
        empty.visibility = View.VISIBLE
        rootFrame.post {
            val (x, y) = posIn(ringHome)
            ringAnimating = true
            ring.speed = 4f
            ring.animate().x(x).y(y).scaleX(1f).scaleY(1f)
                .setDuration(700).setInterpolator(DecelerateInterpolator(1.6f))
                .withEndAction { ringAnimating = false; applyRingSpeed(); snapRing() }.start()
            empty.animate().alpha(1f).setDuration(500).start()
        }
    }

    private fun applyRingSpeed() { ring.speed = if (working) 3.2f else 1f }

    // =====================================================================
    //  status: what Kayron is doing, next to the ring
    // =====================================================================
    private fun refreshStatus() {
        if (working) return
        val who = if (profile == "guest") "Guest" else profile
        status.setTextColor(GREY)
        val eng = if (AI.usingGemini(this)) "Gemini" else "Free AI"
        status.text = "$who \u00B7 $eng \u00B7 ${Usage.today(this)} / ${Prefs.dailyLimit(this)}"
    }

    private fun setWorking(on: Boolean, code: Boolean) {
        working = on; workCode = code
        workStart = System.currentTimeMillis(); progressNote = ""
        applyRingSpeed()
        statusJob?.let { ui.removeCallbacks(it) }; statusJob = null
        if (on) {
            var n = 0
            val r = object : Runnable {
                override fun run() {
                    n = (n + 1) % 4
                    var phase = progressNote.ifEmpty { "Thinking" }
                    if (phase == "Thinking" && workCode && System.currentTimeMillis() - workStart > 2500) {
                        phase = "Writing code"
                        if (!phaseLogged) { phaseLogged = true; addStep("\u270D\uFE0F Writing the code") }
                    }
                    status.setTextColor(ORANGE)
                    status.text = phase + ".".repeat(n)
                    ui.postDelayed(this, 380)
                }
            }
            statusJob = r; ui.post(r)
        } else { endSteps(); refreshStatus() }
    }

    // =====================================================================
    //  live activity log: under your message, on the left, what Kayron is doing right now
    // =====================================================================
    private fun beginSteps() {
        stepViews.clear(); phaseLogged = false
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6.dp(), 2.dp(), 6.dp(), 2.dp()) }
        stepsBox = box
        list.addView(box, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp(); gravity = Gravity.START })
        scrollDown()
    }

    private fun niceStep(p: String) = when (p) {
        "Thinking" -> "\uD83E\uDDE0 Thinking it through"
        "Reviewing" -> "\uD83D\uDD0D Checking the code for mistakes"
        "Polishing" -> "\u2728 Polishing the answer"
        else -> p
    }

    private fun addStep(raw: String) {
        val box = stepsBox ?: return
        val t = niceStep(raw).replace("\n", " ").take(70)
        if (stepViews.lastOrNull()?.tag == t) return
        stepViews.lastOrNull()?.let { it.text = "\u2713 " + it.tag; it.setTextColor(GREY) }
        val v = tv("\u25B8 $t", 13f, ORANGE).apply { tag = t; alpha = 0f; setPadding(0, 2.dp(), 0, 2.dp()) }
        box.addView(v); v.animate().alpha(1f).setDuration(250).start()
        stepViews.add(v); scrollDown()
    }

    private fun endSteps() {
        stepViews.lastOrNull()?.let { it.text = "\u2713 " + it.tag; it.setTextColor(GREY) }
        if (stepViews.isEmpty()) stepsBox?.let { list.removeView(it) }
        stepsBox = null
    }

    // =====================================================================
    //  messages
    // =====================================================================
    private fun userBubble(text: String) {
        val t = TextView(this).apply {
            this.text = text; textSize = 15.5f; setTextColor(Color.WHITE)
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            background = brand(18)
            maxWidth = (resources.displayMetrics.widthPixels * 0.80f).toInt()
            setTextIsSelectable(true)
        }
        list.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 10.dp(); gravity = Gravity.END })
        empty.visibility = View.GONE
    }

    private fun note(msg: String) {
        val t = tv(msg, 13f, GREY).apply { setPadding(6.dp(), 4.dp(), 6.dp(), 4.dp()) }
        list.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
        empty.visibility = View.GONE
        scrollDown()
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun cleanText(s: String): String = s
        .replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        .replace(Regex("(?m)^\\s*[*-]\\s+"), "\u2022 ")

    private fun spans(src: String): CharSequence {
        val sb = SpannableStringBuilder()
        var i = 0
        while (i < src.length) {
            if (src.startsWith("**", i)) {
                val e = src.indexOf("**", i + 2)
                if (e > 0) {
                    val s = sb.length
                    sb.append(src.substring(i + 2, e))
                    sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = e + 2; continue
                }
            }
            if (src[i] == '`') {
                val e = src.indexOf('`', i + 1)
                if (e > 0) {
                    val s = sb.length
                    sb.append(src.substring(i + 1, e))
                    sb.setSpan(TypefaceSpan("monospace"), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(Color.parseColor("#FFB86B")), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = e + 1; continue
                }
            }
            sb.append(src[i]); i++
        }
        return sb
    }

    /** A Kayron reply: normal text in bubbles, code in cards with Copy and Share. */
    private fun replyView(text: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun addText(s: String) {
            val t = s.trim('\n', ' ')
            if (t.isEmpty()) return
            col.addView(TextView(this).apply {
                this.text = spans(cleanText(t)); textSize = 15.5f; setTextColor(Color.parseColor("#EDEDED"))
                setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
                background = pill(Color.parseColor("#151515"), 18)
                maxWidth = (resources.displayMetrics.widthPixels * 0.90f).toInt()
                setLineSpacing(0f, 1.12f)
                setTextIsSelectable(true)
            }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = 8.dp(); gravity = Gravity.START })
        }
        fun addCode(lang: String, code: String) {
            val head = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14.dp(), 8.dp(), 8.dp(), 8.dp())
                addView(tv(lang.ifBlank { "code" }, 12f, GREY), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                val copy = tv("Copy", 13f, ORANGE, true).apply { setPadding(12.dp(), 6.dp(), 12.dp(), 6.dp()) }
                copy.setOnClickListener {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code))
                    copy.text = "Copied \u2713"
                    ui.postDelayed({ copy.text = "Copy" }, 1500)
                }
                addView(copy)
                addView(tv("Share", 13f, ORANGE, true).apply {
                    setPadding(12.dp(), 6.dp(), 12.dp(), 6.dp())
                    setOnClickListener {
                        startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Share code"))
                    }
                })
            }
            val body = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(TextView(this@MainActivity).apply {
                    this.text = code; textSize = 12.5f; typeface = Typeface.MONOSPACE
                    setTextColor(Color.parseColor("#EAEAEA")); setPadding(14.dp(), 4.dp(), 14.dp(), 14.dp())
                    setTextIsSelectable(true)
                })
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = pill(Color.parseColor("#0E0E0E"), 14).apply { setStroke(1.dp(), Color.parseColor("#33FF8C1E")) }
                addView(head); addView(body)
            }
            col.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
        }

        fun addImage(id: String) {
            val bytes = Chats.loadImage(this, profile, id)
            val bmp = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size, BitmapFactory.Options().apply { inSampleSize = 2 }) }
            if (bytes == null || bmp == null) { addText("(this picture is no longer available)"); return }
            val img = ImageView(this).apply {
                setImageBitmap(bmp); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                background = pill(Color.parseColor("#151515"), 16); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
            }
            col.addView(img, LinearLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.84f).toInt(), WRAP_CONTENT)
                .apply { topMargin = 8.dp(); gravity = Gravity.START })
            col.addView(LinearLayout(this).apply {
                addView(tv("Save", 13f, ORANGE, true).apply {
                    setPadding(8.dp(), 8.dp(), 14.dp(), 8.dp())
                    setOnClickListener { text = if (saveToGallery(bytes, id) != null) "Saved \u2713" else "Could not save" }
                })
                addView(tv("Share", 13f, ORANGE, true).apply {
                    setPadding(8.dp(), 8.dp(), 14.dp(), 8.dp())
                    setOnClickListener {
                        saveToGallery(bytes, id)?.let { u ->
                            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("image/jpeg")
                                .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share picture"))
                        }
                    }
                })
            })
        }
        val imgRe = Regex("\\[\\[img:(\\d+)\\]\\]")
        fun addRich(seg: String) {
            var p = 0
            for (m in imgRe.findAll(seg)) {
                addText(seg.substring(p, m.range.first)); addImage(m.groupValues[1]); p = m.range.last + 1
            }
            addText(seg.substring(p))
        }

        val fence = Regex("```([A-Za-z0-9+#._-]*)[ \\t]*\\n?([\\s\\S]*?)(```|$)")
        var pos = 0
        for (m in fence.findAll(text)) {
            addRich(text.substring(pos, m.range.first))
            addCode(m.groupValues[1], m.groupValues[2].trimEnd('\n'))
            pos = m.range.last + 1
        }
        if (pos < text.length) addRich(text.substring(pos))
        return col
    }

    private fun showReply(text: String) {
        val v = replyView(text)
        v.alpha = 0f; v.translationY = 18.dp().toFloat()
        list.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        v.animate().alpha(1f).translationY(0f).setDuration(350).start()
        empty.visibility = View.GONE
        scrollDown()
    }

    // =====================================================================
    //  sending
    // =====================================================================
    private fun looksLikeCode(q: String): Boolean {
        if (ImageGen.wants(q) != null) return false
        val l = q.lowercase().trim()
        if (Regex("^(open|launch|call|dial|text|message|play|navigate|scroll|swipe|next|previous|click|tap|go |read my|check my|remember|forget|set a|set an|turn|volume|take a|auto|stop)").containsMatchIn(l)) return false
        if (l.contains("```")) return true
        val verb = Regex("\\b(write|make|create|build|code|generate|develop|program|fix|debug|refactor|convert|implement|script|add)\\b")
        val noun = Regex("\\b(code|script|program|app|application|game|website|web page|webpage|function|class|bug|error|plugin|mod|bot|api|html|css|javascript|python|java|kotlin|lua|luau|c\\+\\+|c#|unity|godot|roblox|minecraft|react|node|sql|database|algorithm|android)\\b")
        return verb.containsMatchIn(l) && noun.containsMatchIn(l)
    }

    private fun turnsOf(msgs: List<Pair<Boolean, String>>): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var i = 0
        while (i < msgs.size - 1) {
            if (msgs[i].first && !msgs[i + 1].first) { out.add(msgs[i].second to msgs[i + 1].second); i += 2 } else i++
        }
        return out
    }

    private fun send(q0: String) {
        val q = q0.trim()
        if (q.isEmpty()) return
        if (Agent.busy) { Agent.cancel = true; note("Okay, stopping what I was doing\u2026"); return }
        hideKeyboard()
        input.setText("")

        val pf = profile
        val cid = chatId
        Agent.history = turnsOf(Chats.load(this, pf, cid))
        val first = !hasMessages
        hasMessages = true
        userBubble(q)
        beginSteps()
        Chats.add(this, pf, cid, true, q)
        if (first) ringToHeader()
        scrollDown()

        val code = codeForced || looksLikeCode(q)
        setWorking(true, code)
        Thread {
            val r = if (code) Agent.runCode(this, q) { p -> runOnUiThread { progressNote = p; addStep(p) } }
                    else Agent.run(this, q) { p -> runOnUiThread { progressNote = p; addStep(p) } }
            val text = r.ifBlank { "Done." }
            Chats.add(this, pf, cid, false, text)
            runOnUiThread {
                setWorking(false, false)
                if (pf == profile && cid == chatId) showReply(text)
                if (Prefs.speak(this)) Speaker.say(this, speakable(r))
            }
        }.start()
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    // =====================================================================
    //  chats and accounts
    // =====================================================================
    /** Picks the chat to show for the current account (the last one used, or a fresh one). */
    private fun chooseChat() {
        val saved = Prefs.activeChat(this, profile)
        val all = Chats.list(this, profile)
        chatId = when {
            all.any { it.id == saved } -> saved
            all.isNotEmpty() -> all.first().id
            else -> Chats.create(this, profile)
        }
        Prefs.setActiveChat(this, profile, chatId)
    }

    private fun loadChat(animate: Boolean) {
        list.removeAllViews()
        val msgs = Chats.load(this, profile, chatId)
        hasMessages = msgs.isNotEmpty()
        for ((isUser, t) in msgs) if (isUser) userBubble(t) else list.addView(replyView(t), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        if (hasMessages) {
            empty.visibility = View.GONE
            if (animate && !ringAtHeader) ringToHeader() else { ringAtHeader = true; rootFrame.post { snapRing() } }
        } else {
            empty.visibility = View.VISIBLE; empty.alpha = 1f
            if (animate && ringAtHeader) ringToCenter() else { ringAtHeader = false; rootFrame.post { snapRing() } }
        }
        scrollDown()
    }

    private fun openChat(id: String) {
        chatId = id
        Prefs.setActiveChat(this, profile, id)
        loadChat(true)
        closeDrawer()
    }

    private fun newChat() {
        if (hasMessages) {
            chatId = Chats.create(this, profile)
            Prefs.setActiveChat(this, profile, chatId)
            loadChat(true)
        }
        closeDrawer()
    }

    private fun onProfileChanged() {
        profile = Prefs.profile(this)
        updateSecure()
        chooseChat()
        loadChat(true)
        refreshStatus()
        closeDrawer()
    }

    /** Shows the chats of the current (unlocked) account. */
    private fun startProfileUi() {
        updateSecure()
        chooseChat()
        loadChat(false)
        refreshStatus()
    }

    /** A protected account hides itself from the recent-apps picture and from screenshots. */
    private fun updateSecure() {
        if (profile != "guest" || lockLayer != null) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun needsUnlock(p: String) = p != "guest" && !Auth.isUnlocked(p)

    private fun speakable(r: String) = r.replace(Regex("\\[\\[img:\\d+\\]\\]"), " Here is your picture. ")
        .replace(Regex("[\\p{So}\\p{Cs}\\uFE0F]"), "")

    private fun saveToGallery(bytes: ByteArray, id: String): Uri? = try {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Kayron_$id.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Kayron")
        }
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        if (u != null) contentResolver.openOutputStream(u)?.use { it.write(bytes) }
        u
    } catch (e: Exception) { null }

    // ---------------------------------------------------------------- login for each account
    private fun canBio(): Boolean = try {
        getSystemService(BiometricManager::class.java).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS
    } catch (e: Exception) { false }

    /** Fingerprint/face (deviceCredential = false) or the phone's own screen lock too (true). */
    private fun bioPrompt(title: String, deviceCredential: Boolean, onOk: () -> Unit) {
        try {
            val b = BiometricPrompt.Builder(this).setTitle(title)
            if (deviceCredential)
                b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            else {
                b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                b.setNegativeButton("Use password", mainExecutor) { _, _ -> }
            }
            b.build().authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { onOk() }
                override fun onAuthenticationError(code: Int, msg: CharSequence?) {
                    if (deviceCredential && code != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED && code != BiometricPrompt.BIOMETRIC_ERROR_CANCELED)
                        note("Could not confirm it is you: $msg")
                }
            })
        } catch (e: Exception) { if (deviceCredential) note("Set a screen lock on your phone first, then try again.") }
    }

    private fun lockNow() {
        if (profile == "guest") return
        Auth.lock(profile)
        closeDrawerNow()
        showLock(profile)
    }

    private fun closeDrawerNow() {
        drawerOpen = false; scrim.visibility = View.GONE; scrim.alpha = 0f
        drawer.visibility = View.GONE; drawer.translationX = -drawerW.toFloat()
    }

    private fun finishUnlock(p: String) {
        Auth.unlock(p)
        lockLayer?.let { rootFrame.removeView(it) }; lockLayer = null
        Prefs.setProfile(this, p); profile = p
        startProfileUi()
    }

    private fun showLock(p: String) {
        list.removeAllViews()
        lockLayer?.let { rootFrame.removeView(it) }
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        fun pwField(h: String) = EditText(this).apply {
            hint = h; setSingleLine(); textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE); setHintTextColor(GREY)
            setPadding(16.dp(), 12.dp(), 16.dp(), 12.dp()); background = pill(Color.parseColor("#151515"), 14)
        }
        val pw = pwField("Password")
        val msg = tv("", 13f, GREY).apply { gravity = Gravity.CENTER }
        fun bad(t: String) { msg.setTextColor(Color.parseColor("#FF6B5B")); msg.text = t }
        fun tryUnlock() {
            val w = Auth.waitMs(this, p)
            if (w > 0) { bad("Too many wrong tries. Wait ${w / 1000 + 1} seconds."); return }
            if (Auth.check(this, p, pw.text.toString())) { pw.setText(""); finishUnlock(p) }
            else {
                val w2 = Auth.waitMs(this, p)
                bad(if (w2 > 0) "Too many wrong tries. Locked for ${w2 / 1000 + 1} seconds." else "Wrong password. ${Auth.triesLeft(this, p)} tries left.")
            }
        }
        pw.setOnEditorActionListener { _, _, _ -> tryUnlock(); true }
        fun link(label: String, run: () -> Unit) = tv(label, 14f, ORANGE, true).apply {
            gravity = Gravity.CENTER; setPadding(10.dp(), 12.dp(), 10.dp(), 12.dp()); setOnClickListener { run() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28.dp(), 60.dp(), 28.dp(), 40.dp())
            addView(RingView(this@MainActivity), LinearLayout.LayoutParams(150.dp(), 150.dp()))
            addView(tv("Kayron is locked \uD83D\uDD12", 20f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 14.dp() })
            addView(tv(p, 14f, GREY).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 4.dp() })
            addView(pw, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 22.dp() })
            addView(msg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
            addView(tv("Unlock", 16f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, 14.dp(), 0, 14.dp()); background = brand(14); setOnClickListener { tryUnlock() }
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 10.dp() })
            if (Auth.biometric(this@MainActivity, p) && canBio())
                addView(link("Use fingerprint / face") { bioPrompt("Unlock Kayron", false) { finishUnlock(p) } })
            addView(link("Forgot password?") { forgotPassword(p) })
            addView(link("Use Guest instead") {
                lockLayer?.let { rootFrame.removeView(it) }; lockLayer = null
                Prefs.setProfile(this@MainActivity, "guest"); onProfileChanged()
            })
        }
        val layer = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true; addView(box) }
        lockLayer = layer
        rootFrame.addView(layer, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        if (Auth.biometric(this, p) && canBio()) bioPrompt("Unlock Kayron", false) { finishUnlock(p) }
    }

    /** Choose a password for an account (when it is added, reset or changed). */
    private fun createPassword(email: String, reset: Boolean, done: (Boolean) -> Unit) {
        fun pwField(h: String) = EditText(this).apply {
            hint = h; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val a = pwField("New password"); val b = pwField("Repeat password")
        val bio = CheckBox(this).apply { text = "Unlock with fingerprint / face"; isChecked = canBio(); visibility = if (canBio()) View.VISIBLE else View.GONE }
        val err = tv("", 12f, Color.parseColor("#D32F2F"))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22.dp(), 10.dp(), 22.dp(), 0)
            addView(tv("Kayron will ask for this password every time $email is opened. Use 8 or more characters, with letters and numbers.", 13f, Color.GRAY))
            addView(a); addView(b); addView(bio); addView(err)
        }
        val d = AlertDialog.Builder(this).setTitle(if (reset) "Choose a new password" else "Protect $email")
            .setView(box).setCancelable(false)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel") { _, _ -> done(false) }.create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val w = Auth.weak(a.text.toString(), email)
                when {
                    w != null -> err.text = w
                    a.text.toString() != b.text.toString() -> err.text = "The two passwords are not the same."
                    else -> {
                        Auth.set(this, email, a.text.toString())
                        Auth.setBiometric(this, email, bio.isChecked && canBio())
                        d.dismiss(); done(true)
                    }
                }
            }
        }
        d.show()
    }

    private fun changePassword() {
        val cur = EditText(this).apply {
            hint = "Current password"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("Change password")
            .setView(LinearLayout(this).apply { setPadding(22.dp(), 10.dp(), 22.dp(), 0); addView(cur, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) })
            .setPositiveButton("Next") { _, _ ->
                if (Auth.check(this, profile, cur.text.toString())) createPassword(profile, true) { ok -> if (ok) note("Password changed.") }
                else note("That is not the current password.")
            }.setNegativeButton("Cancel", null).show()
    }

    /** Forgot the password: prove it is your Google account, then confirm with the phone's own lock. */
    private fun forgotPassword(p: String) {
        pendingReset = p; skipLock = true
        startActivityForResult(GoogleSignIn.getClient(this, GmailApi.options(p)).signInIntent, 9)
    }

    private fun switchProfile(p: String) {
        if (p == profile) { closeDrawer(); return }
        closeDrawer()
        if (profile != "guest") Auth.lock(profile)
        Prefs.setProfile(this, p); profile = p
        if (needsUnlock(p)) showLock(p) else onProfileChanged()
    }

    private fun addAccount() {
        skipLock = true; pendingReset = null
        val cl = GoogleSignIn.getClient(this, GmailApi.options())
        cl.signOut().addOnCompleteListener { startActivityForResult(cl.signInIntent, 9) }
    }

    /** Connect Gmail (read / send mail) for the account that is open. */
    private fun connectGmail() {
        if (profile == "guest") { addAccount(); return }
        skipLock = true; pendingReset = null
        startActivityForResult(GoogleSignIn.getClient(this, GmailApi.options(profile)).signInIntent, 9)
    }

    private fun removeAccount(p: String) {
        AlertDialog.Builder(this).setTitle("Remove $p?")
            .setMessage("This deletes its chats, pictures, memory and password from this phone. Your Google account is not touched.")
            .setPositiveButton("Remove") { _, _ ->
                Chats.deleteAll(this, p); Memory.deleteFor(this, p); Crypto.deleteKey(p); Auth.remove(this, p); Prefs.removeProfile(this, p)
                if (p == profile) {
                    lockLayer?.let { rootFrame.removeView(it) }; lockLayer = null
                    profile = "guest"; onProfileChanged()
                }
                refreshDrawer()
            }.setNegativeButton("Cancel", null).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq != 9) return
        GoogleSignIn.getSignedInAccountFromIntent(d)
            .addOnSuccessListener {
                val email = (it.email ?: "").lowercase()
                if (email.isBlank()) return@addOnSuccessListener
                val reset = pendingReset; pendingReset = null
                when {
                    reset != null -> {
                        if (email != reset) { note("That was a different Google account ($email). Choose $reset to reset its password."); return@addOnSuccessListener }
                        bioPrompt("Confirm it is you", true) {
                            createPassword(email, true) { ok -> if (ok) finishUnlock(email) }
                        }
                    }
                    email == profile && Auth.isUnlocked(email) -> { refreshStatus(); note("Gmail is connected for $email.") }
                    Auth.hasPassword(this, email) -> {
                        // already protected on this phone: the app password is still needed
                        if (profile != "guest") Auth.lock(profile)
                        Prefs.addProfile(this, email); Prefs.setProfile(this, email); profile = email
                        showLock(email)
                    }
                    else -> createPassword(email, false) { ok ->
                        if (ok) {
                            if (profile != "guest") Auth.lock(profile)
                            Prefs.addProfile(this, email); Prefs.setProfile(this, email); Auth.unlock(email)
                            onProfileChanged()
                            note("Signed in as $email. This account has its own password, chats and memory.")
                        }
                    }
                }
            }
            .addOnFailureListener { note("Gmail sign-in failed: ${it.message}. See the README, Gmail step.") }
    }

    // ---------------------------------------------------------------- drawer
    private fun row(label: String, selected: Boolean = false, onClick: () -> Unit): TextView =
        tv(label, 15f, if (selected) ORANGE else Color.parseColor("#E6E6E6"), selected).apply {
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            if (selected) background = pill(Color.parseColor("#1F1409"), 12)
            maxLines = 1
            setOnClickListener { onClick() }
        }

    private fun refreshDrawer() {
        drawerBody.removeAllViews()
        fun add(v: View, top: Int = 2) = drawerBody.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = top.dp() })
        fun label(s: String) = add(tv(s, 11f, GREY, true).apply { setPadding(14.dp(), 14.dp(), 0, 4.dp()) })

        add(tv("Kayron", 22f, Color.WHITE, true).apply { setPadding(14.dp(), 14.dp(), 0, 4.dp()) })

        add(tv("\uFF0B  New chat", 15f, Color.WHITE, true).apply {
            setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp()); background = brand(14)
            setOnClickListener { newChat() }
        }, 10)

        label("ACCOUNT")
        for (p in listOf("guest") + Prefs.profiles(this))
            add(row((if (p == "guest") "\uD83D\uDC64  Guest" else "\uD83D\uDD12  $p"), p == profile) { switchProfile(p) }.apply {
                if (p != "guest") setOnLongClickListener { removeAccount(p); true }
            })
        add(row("\uFF0B  Add Gmail account") { closeDrawer(); addAccount() })
        if (profile != "guest") add(row("\uD83D\uDD12  Lock now") { lockNow() })
        else add(tv("Guest has no login and is not protected.", 11f, GREY).apply { setPadding(14.dp(), 4.dp(), 0, 0) })

        label("CHATS")
        val chats = Chats.list(this, profile)
        if (chats.isEmpty()) add(tv("No chats yet", 13f, GREY).apply { setPadding(14.dp(), 6.dp(), 0, 6.dp()) })
        for (m in chats) {
            add(row(m.title.ifBlank { "New chat" }, m.id == chatId) { openChat(m.id) }.apply {
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Delete this chat?")
                        .setMessage(m.title)
                        .setPositiveButton("Delete") { _, _ ->
                            Chats.delete(this@MainActivity, profile, m.id)
                            if (m.id == chatId) { chooseChat(); loadChat(true) }
                            refreshDrawer()
                        }.setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
    }

    private fun openDrawer() {
        if (drawerOpen || lockLayer != null) return
        drawerOpen = true
        hideKeyboard()
        refreshDrawer()
        scrim.visibility = View.VISIBLE; drawer.visibility = View.VISIBLE
        scrim.animate().alpha(1f).setDuration(220).start()
        drawer.animate().translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        scrim.animate().alpha(0f).setDuration(200).withEndAction { scrim.visibility = View.GONE }.start()
        drawer.animate().translationX(-drawerW.toFloat()).setDuration(220)
            .withEndAction { drawer.visibility = View.GONE }.start()
    }

    // =====================================================================
    //  setup and settings
    // =====================================================================
    private fun checklist() {
        fun open(i: Intent): () -> Unit = { startActivity(i) }
        val pkg = Uri.parse("package:$packageName")
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val rows: List<Triple<Boolean, String, () -> Unit>> = listOf(
            Triple(true, "AI: works free with no key (a Gemini key in settings is optional)", { settings() }),
            Triple(KayronAccessibility.inst != null, "Accessibility: lets Kayron see the screen, tap, scroll",
                open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))),
            Triple(KayronNotifications.connected, "Notification access: read your notifications",
                open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))),
            Triple(contacts, "Contacts: call or text people by name",
                { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 1) }),
            Triple(GmailApi.account(this) != null, "Gmail: read and send email for this account", { connectGmail() }),
            Triple(false, "If a switch is blocked: App info > \u22EE > Allow restricted settings",
                open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)))
        )
        AlertDialog.Builder(this).setTitle("Set up Kayron")
            .setItems(rows.map { (if (it.first) "\u2705 " else "\u2B1C ") + it.second }.toTypedArray()) { _, i -> rows[i].third() }
            .setNegativeButton("Done", null).show()
    }

    private fun settings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22.dp(), 12.dp(), 22.dp(), 0)
        }
        fun field(hint: String, value: String) = EditText(this).apply {
            this.hint = hint; setText(value); setSingleLine(); textSize = 14f
        }
        fun btn(label: String, run: () -> Unit) = tv(label, 14f).apply {
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            background = pill(Color.parseColor("#2A2A2A"))
            setOnClickListener { run() }
        }.also {
            box.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 8.dp() })
        }

        val key = field("Gemini key (optional)", Prefs.key(this))
        val model = field("Chat model", Prefs.model(this))
        val codeModel = field("Code model", Prefs.codeModel(this))
        val limit = field("Daily limit of AI requests", Prefs.dailyLimit(this).toString())
        limit.inputType = InputType.TYPE_CLASS_NUMBER
        box.addView(tv("Optional: a free Gemini key (aistudio.google.com/apikey) gives better, faster answers. Without it Kayron uses its built-in free AI.", 12f, Color.GRAY))
        box.addView(key)
        box.addView(tv("Models (a stronger code model gives better code, if your key allows it)", 12f, Color.GRAY).apply { setPadding(0, 10.dp(), 0, 0) })
        box.addView(model); box.addView(codeModel)
        box.addView(tv("Daily limit of AI requests", 12f, Color.GRAY).apply { setPadding(0, 10.dp(), 0, 0) })
        box.addView(limit)

        btn("Get a free Gemini key (optional)") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }
        val speakBtn = btn("") { }
        fun speakText() { speakBtn.text = if (Prefs.speak(this)) "Read replies aloud: ON (tap to turn off)" else "Read replies aloud: OFF (tap to turn on)" }
        speakText()
        speakBtn.setOnClickListener { Prefs.setSpeak(this, !Prefs.speak(this)); speakText() }
        if (profile != "guest") {
            btn("Change this account's password") { changePassword() }
            if (canBio()) {
                val bioBtn = btn("") { }
                fun bioText() { bioBtn.text = if (Auth.biometric(this, profile)) "Fingerprint / face unlock: ON (tap to turn off)" else "Fingerprint / face unlock: OFF (tap to turn on)" }
                bioText()
                bioBtn.setOnClickListener { Auth.setBiometric(this, profile, !Auth.biometric(this, profile)); bioText() }
            }
        }
        btn("Set up Kayron (checklist)") { checklist() }
        btn("Allow notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("What Kayron remembers") { memory() }

        AlertDialog.Builder(this).setTitle("Kayron settings")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                Prefs.setKey(this, key.text.toString())
                Prefs.setModel(this, model.text.toString())
                Prefs.setCodeModel(this, codeModel.text.toString())
                Prefs.setDailyLimit(this, limit.text.toString().toIntOrNull() ?: 200)
                refreshStatus()
                note("Saved.")
            }.setNegativeButton("Close", null).show()
    }

    private fun memory() {
        val f = Memory.facts(this)
        AlertDialog.Builder(this).setTitle("What Kayron remembers")
            .setMessage(if (f.isEmpty()) "Nothing yet. Tell Kayron: \u201Cremember that my name is \u2026\u201D" else f.joinToString("\n") { "\u2022 $it" })
            .setPositiveButton("Close", null)
            .setNegativeButton("Forget all") { _, _ -> Memory.forget(this, null); note("Memory cleared.") }
            .show()
    }
}
