package com.kayron.mobile

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Free answers: built-in replies, maths, and Wikipedia. No API key needed. */
object Brain {
    private val fullForms = mapOf(
        "ai" to "Artificial Intelligence", "ml" to "Machine Learning", "cpu" to "Central Processing Unit",
        "gpu" to "Graphics Processing Unit", "ram" to "Random Access Memory", "rom" to "Read Only Memory",
        "url" to "Uniform Resource Locator", "pdf" to "Portable Document Format", "usb" to "Universal Serial Bus",
        "html" to "HyperText Markup Language", "wifi" to "Wireless Fidelity", "gps" to "Global Positioning System",
        "sms" to "Short Message Service", "atm" to "Automated Teller Machine",
        "isro" to "Indian Space Research Organisation", "nasa" to "National Aeronautics and Space Administration",
        "upi" to "Unified Payments Interface"
    )

    private val jokes = listOf(
        "Why did the phone go to school? To get smarter.",
        "I told my computer I needed a break, and now it will not stop sending me vacation ads.",
        "Why was the computer cold? It left its Windows open."
    )

    private fun math(l: String): String? {
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*(plus|\\+|minus|-|times|multiplied by|x|\\*|into|divided by|/|over)\\s*(-?\\d+(?:\\.\\d+)?)")
            .find(l) ?: return null
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val r = when (m.groupValues[2]) {
            "plus", "+" -> a + b
            "minus", "-" -> a - b
            "times", "multiplied by", "x", "*", "into" -> a * b
            else -> if (b == 0.0) return "I cannot divide by zero." else a / b
        }
        return "The answer is " + (if (r % 1.0 == 0.0) r.toLong().toString() else "%.2f".format(r))
    }

    fun ask(q: String): String {
        val l = q.lowercase().replace(Regex("[?.!,]"), "").trim()

        Regex("(?:full form of|stands for|stand for) (\\w+)").find(l)?.let { m ->
            fullForms[m.groupValues[1]]?.let { return "${m.groupValues[1].uppercase()} stands for $it." }
        }
        Regex("what does (\\w+) stand for").find(l)?.let { m ->
            fullForms[m.groupValues[1]]?.let { return "${m.groupValues[1].uppercase()} stands for $it." }
        }
        if (Regex("your name|who are you").containsMatchIn(l)) return "I am Kayron, your voice assistant."
        if (Regex("^(hi|hello|hey)\\b").containsMatchIn(l)) return "Hello! How can I help you?"
        if (Regex("how are you").containsMatchIn(l)) return "I am doing great, thank you for asking."
        if (Regex("thank").containsMatchIn(l)) return "You are welcome."
        if (Regex("\\bjoke\\b").containsMatchIn(l)) return jokes.random()
        if (Regex("what('s| is) the time|what time|current time").containsMatchIn(l))
            return "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        if (Regex("what('s| is) the date|today's date|what day|which day").containsMatchIn(l))
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
        math(l)?.let { return it }

        return try {
            val term = l.replace(Regex("^(what is|what are|what was|who is|who was|tell me about|meaning of|define|explain)\\s+(the\\s+|an?\\s+)?"), "")
            val url = "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" +
                URLEncoder.encode(term, "UTF-8") +
                "&gsrlimit=1&prop=extracts&exintro=1&explaintext=1&exsentences=2&format=json"
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "KayronMobile/1.0")
            c.connectTimeout = 8000; c.readTimeout = 8000
            val pages = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("query").getJSONObject("pages")
            pages.getJSONObject(pages.keys().next()).getString("extract")
        } catch (e: Exception) {
            "Sorry, I could not find that."
        }
    }
}
