package com.kayron.mobile

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Shared live state used by the screen, the orb and the background listener. */
object Audio {
    @Volatile var level = 0f            // voice loudness 0..1
    @Volatile var state = "idle"        // idle | listening | thinking | working | speaking
    @Volatile var appOpen = false
    @Volatile var heard = ""            // last thing you said
    @Volatile var reply = ""            // last Kayron answer
    @Volatile var engine = "android"    // wake engine in use: android | porcupine
    @Volatile var lock = false          // true when only your registered voice is obeyed
}

/** One shared text-to-speech voice. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var done: () -> Unit = {}
    private val main = Handler(Looper.getMainLooper())

    fun say(c: Context, text: String, onDone: () -> Unit = {}) {
        done = onDone
        if (text.isBlank()) { onDone(); return }
        Audio.reply = text
        if (tts == null) {
            tts = TextToSpeech(c.applicationContext) { s ->
                ready = s == TextToSpeech.SUCCESS
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { Audio.state = "speaking" }
                    override fun onDone(id: String?) { Audio.state = "idle"; main.post { done() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { Audio.state = "idle"; main.post { done() } }
                })
                pending?.let { p -> pending = null; speakNow(p) }
            }
        }
        if (ready) speakNow(text) else pending = text
    }

    fun stop() { try { tts?.stop() } catch (e: Exception) {}; Audio.state = "idle" }

    private fun speakNow(t: String) {
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "kayron")
    }
}
