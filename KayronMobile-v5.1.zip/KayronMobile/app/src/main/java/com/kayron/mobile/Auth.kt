package com.kayron.mobile

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Each Gmail account has its own Kayron password. It is never stored: only a salted PBKDF2 hash is.
 * Too many wrong tries lock that account for a while (30 s, then longer and longer).
 */
object Auth {
    private const val ITER = 150_000
    private val unlocked = HashSet<String>()
    @Volatile var leftAt = 0L

    private fun sp(c: Context) = c.getSharedPreferences("kayron_auth", Context.MODE_PRIVATE)
    private fun k(p: String) = p.lowercase()

    private fun hash(pw: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pw.toCharArray(), salt, ITER, 256)).encoded

    fun hasPassword(c: Context, p: String) = sp(c).contains("h_" + k(p))

    /** Returns a message if the password is too weak, or null if it is fine. */
    fun weak(pw: String, email: String): String? = when {
        pw.length < 8 -> "Use at least 8 characters."
        pw.none { it.isLetter() } || pw.none { it.isDigit() } -> "Use letters and numbers together."
        pw.lowercase() == email.substringBefore("@").lowercase() || pw.lowercase() == "password1" -> "That password is too easy to guess."
        else -> null
    }

    fun set(c: Context, p: String, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp(c).edit()
            .putString("h_" + k(p), Base64.encodeToString(hash(pw, salt), Base64.NO_WRAP))
            .putString("s_" + k(p), Base64.encodeToString(salt, Base64.NO_WRAP))
            .putInt("f_" + k(p), 0).putLong("l_" + k(p), 0).apply()
    }

    /** Milliseconds left until another try is allowed (0 = allowed now). */
    fun waitMs(c: Context, p: String): Long = maxOf(0L, sp(c).getLong("l_" + k(p), 0) - System.currentTimeMillis())

    fun check(c: Context, p: String, pw: String): Boolean {
        if (waitMs(c, p) > 0) return false
        val h = sp(c).getString("h_" + k(p), null) ?: return false
        val s = sp(c).getString("s_" + k(p), null) ?: return false
        val ok = MessageDigest.isEqual(Base64.decode(h, Base64.NO_WRAP), hash(pw, Base64.decode(s, Base64.NO_WRAP)))
        if (ok) {
            sp(c).edit().putInt("f_" + k(p), 0).putLong("l_" + k(p), 0).apply()
            unlocked.add(k(p))
        } else {
            val f = sp(c).getInt("f_" + k(p), 0) + 1
            val lock = if (f >= 5) minOf(15 * 60_000L, 30_000L shl minOf(f - 5, 5)) else 0L
            sp(c).edit().putInt("f_" + k(p), f).putLong("l_" + k(p), if (lock > 0) System.currentTimeMillis() + lock else 0).apply()
        }
        return ok
    }

    fun triesLeft(c: Context, p: String) = maxOf(0, 5 - sp(c).getInt("f_" + k(p), 0))

    fun isUnlocked(p: String) = p == "guest" || k(p) in unlocked
    fun unlock(p: String) { unlocked.add(k(p)) }
    fun lockAll() { unlocked.clear() }
    fun lock(p: String) { unlocked.remove(k(p)) }

    fun biometric(c: Context, p: String) = sp(c).getBoolean("b_" + k(p), false)
    fun setBiometric(c: Context, p: String, v: Boolean) = sp(c).edit().putBoolean("b_" + k(p), v).apply()

    fun remove(c: Context, p: String) {
        sp(c).edit().remove("h_" + k(p)).remove("s_" + k(p)).remove("f_" + k(p)).remove("l_" + k(p)).remove("b_" + k(p)).apply()
        unlocked.remove(k(p))
    }
}
