package com.kayron.mobile

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import java.net.URLEncoder

/** Turns what you said into a phone action. Returns the spoken reply, or null if it was not a command. */
object Commands {
    private const val needA = "Please turn on Kayron in Accessibility settings first."

    private fun go(c: Context, i: Intent): Boolean = try {
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun lookup(c: Context, name: String): String? = try {
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }

    private fun number(c: Context, who: String): String? {
        val digits = who.replace(Regex("[^0-9+]"), "")
        return if (digits.length >= 5) digits else lookup(c, who)
    }

    internal fun openApp(c: Context, name: String): String {
        val pm = c.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(li, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val launch = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        return if (launch != null && go(c, launch)) "Opening $name" else "I could not find $name on your phone"
    }

    fun run(c: Context, raw: String): String? {
        val t = raw.lowercase().replace(Regex("[.,!?]"), "").trim()
        val a = KayronAccessibility.inst

        // ---- hands-free reels (quiet: no spoken reply, so the video audio is not disturbed) ----
        if (Regex("^stop (auto ?scroll|auto ?scrolling|scrolling)").containsMatchIn(t)) {
            a?.stopAuto(); return ""
        }
        Regex("^(?:start )?auto ?scroll(?: every (\\d+) seconds?)?$").find(t)?.let { x ->
            if (a == null) return needA
            val s = x.groupValues[1].ifEmpty { "8" }.toInt()
            a.startAuto(s)
            return "Auto scrolling every $s seconds. Say Kayron stop to end it."
        }
        if (Regex("^(?:go to the |show the |play the )?next (reel|video|short|post)").containsMatchIn(t)) {
            if (a == null) return needA
            a.swipe("down"); return ""
        }
        if (Regex("^(?:go to the |show the )?(previous|last) (reel|video|short|post)").containsMatchIn(t)) {
            if (a == null) return needA
            a.swipe("up"); return ""
        }
        if (Regex("^(double tap|like this( reel| video| post)?|like it)$").containsMatchIn(t)) {
            if (a == null) return needA
            a.doubleTap(); return ""
        }
        if (Regex("^(pause|play|resume)( the)?( video| reel)?$").containsMatchIn(t)) {
            if (a == null) return needA
            val m = c.resources.displayMetrics
            a.tapAt(m.widthPixels / 2f, m.heightPixels / 2f); return ""
        }
        if (t.contains("initiate command 1") || t.contains("initiate command one")) {
            go(c, Intent(c, MainActivity::class.java).putExtra("setup", true)); return "Opening setup"
        }
        if (Regex("(read|check|any|what are|what s) (my )?(new |latest )?notifications").containsMatchIn(t))
            return KayronNotifications.recent(5)
        if (Regex("(check|read|open) (my )?(mail|email|inbox|gmail)").containsMatchIn(t)) {
            val gm = c.packageManager.getLaunchIntentForPackage("com.google.android.gm")
            return if (gm != null && go(c, gm)) "Opening Gmail" else "Gmail is not installed"
        }
        Regex("^(?:compose |send |write )?(?:an )?(?:email|mail)(?: to)? ?(.*?)(?: (?:about|saying) (.+))?$").find(t)?.let { e ->
            val to = e.groupValues[1].replace(" at ", "@").replace(" dot ", ".").replace(" ", "")
            val body = e.groupValues[2]
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                .putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
                .putExtra(Intent.EXTRA_SUBJECT, body)
                .putExtra(Intent.EXTRA_TEXT, body)
            val ok = go(c, Intent(i).setPackage("com.google.android.gm")) || go(c, i)
            return if (ok) "Opening a new email" else "I could not open email"
        }
        Regex("^(open|launch|start) (.+)").find(t)?.let {
            return openApp(c, it.groupValues[2].removeSuffix(" app").trim())
        }
        Regex("^(?:call|dial|phone) (.+)").find(t)?.let { x ->
            val n = number(c, x.groupValues[1]) ?: return "I could not find ${x.groupValues[1]} in your contacts"
            go(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))); return "Calling ${x.groupValues[1]}"
        }
        Regex("^(?:text|message|sms) (.+?)(?: saying (.+))?$").find(t)?.let { x ->
            val n = number(c, x.groupValues[1]) ?: return "I could not find ${x.groupValues[1]} in your contacts"
            go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", x.groupValues[2]))
            return "Opening a message to ${x.groupValues[1]}"
        }
        Regex("^(?:search|google|look up) (.+)").find(t)?.let { x ->
            go(c, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, x.groupValues[1]))
            return "Searching ${x.groupValues[1]}"
        }
        Regex("^play (.+?)(?: on youtube)?$").find(t)?.let { x ->
            go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(x.groupValues[1], "UTF-8"))))
            return "Playing ${x.groupValues[1]}"
        }
        Regex("^(?:navigate to|directions to|take me to) (.+)").find(t)?.let { x ->
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + URLEncoder.encode(x.groupValues[1], "UTF-8")))
            go(c, Intent(i).setPackage("com.google.android.apps.maps")) || go(c, i)
            return "Navigating to ${x.groupValues[1]}"
        }
        Regex("timer for (\\d+) (second|minute|hour)").find(t)?.let { x ->
            val n = x.groupValues[1].toInt()
            val s = n * when (x.groupValues[2]) { "hour" -> 3600; "minute" -> 60; else -> 1 }
            go(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Timer set"
        }
        Regex("alarm for (\\d{1,2})(?::| )?(\\d{2})? ?(am|pm)?").find(t)?.let { x ->
            var h = x.groupValues[1].toInt()
            val mi = x.groupValues[2].ifEmpty { "0" }.toInt()
            if (x.groupValues[3] == "pm" && h < 12) h += 12
            if (x.groupValues[3] == "am" && h == 12) h = 0
            go(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, mi).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Alarm set"
        }
        Regex("(on|off) (?:the )?(?:flashlight|torch)|(?:flashlight|torch) (on|off)").find(t)?.let { x ->
            val on = (x.groupValues[1] + x.groupValues[2]) == "on"
            return try {
                val cm = c.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, on)
                if (on) "Flashlight on" else "Flashlight off"
            } catch (e: Exception) { "I could not control the flashlight" }
        }
        Regex("volume (up|down)").find(t)?.let { x ->
            val am = c.getSystemService(AudioManager::class.java)
            repeat(3) {
                am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (x.groupValues[1] == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            return "Volume ${x.groupValues[1]}"
        }
        Regex("(wifi|bluetooth|display|location|battery) settings").find(t)?.let { x ->
            go(c, Intent(when (x.groupValues[1]) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            }))
            return "Opening ${x.groupValues[1]} settings"
        }
        if (Regex("take (a )?(photo|picture|selfie)").containsMatchIn(t)) {
            go(c, Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return "Opening the camera"
        }
        if (t.contains("battery") && !t.contains("settings")) {
            val b = c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return "Your battery is at $b percent"
        }

        // ---- needs the Accessibility switch ----
        Regex("^scroll (up|down|left|right)").find(t)?.let { x ->
            if (a == null) return needA
            a.swipe(x.groupValues[1]); return ""
        }
        Regex("^swipe (up|down|left|right)").find(t)?.let { x ->
            if (a == null) return needA
            a.swipe(x.groupValues[1]); return ""
        }
        Regex("^(?:click|tap|press) (.+)").find(t)?.let { x ->
            if (a == null) return needA
            return if (a.clickText(x.groupValues[1])) "Tapped ${x.groupValues[1]}" else "I could not see ${x.groupValues[1]} on the screen"
        }
        Regex("^type (.+)").find(t)?.let { x ->
            if (a == null) return needA
            return if (a.type(x.groupValues[1])) "Typed" else "Tap a text box first"
        }
        if (t == "go back" || t == "back") {
            if (a == null) return needA
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); return "Going back"
        }
        if (t == "go home" || t == "home") {
            if (a == null) return needA
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return "Going home"
        }
        if (t.contains("recent apps")) {
            if (a == null) return needA
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); return "Showing recent apps"
        }
        if (t.contains("notification")) {
            if (a == null) return needA
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); return "Opening notifications"
        }
        if (t.contains("screenshot")) {
            if (a == null) return needA
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); return "Taking a screenshot"
        }
        if (t.contains("lock the screen") || t == "lock phone") {
            if (a == null) return needA
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); return "Locking the screen"
        }
        return null
    }
}
