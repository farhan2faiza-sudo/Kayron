package com.kayron.mobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Lets Kayron scroll, tap, type and press system buttons in any app. */
class KayronAccessibility : AccessibilityService() {
    companion object {
        @Volatile var inst: KayronAccessibility? = null
    }

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { stopAuto(); inst = null; super.onDestroy() }

    /** "scroll down" = content moves up = the finger swipes up. */
    fun swipe(dir: String) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        val v = when (dir) {
            "down" -> listOf(w / 2, h * 0.7f, w / 2, h * 0.3f)
            "up" -> listOf(w / 2, h * 0.3f, w / 2, h * 0.7f)
            "left" -> listOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> listOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
        }
        val p = Path().apply { moveTo(v[0], v[1]); lineTo(v[2], v[3]) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 250)).build(), null, null)
    }

    // ---- hands-free reels: auto scroll and double tap ----
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var autoSec = 0
    private val autoTick = object : Runnable {
        override fun run() {
            if (autoSec > 0) { swipe("down"); ui.postDelayed(this, autoSec * 1000L) }
        }
    }

    fun startAuto(sec: Int) {
        stopAuto()
        autoSec = sec.coerceIn(2, 120)
        ui.postDelayed(autoTick, autoSec * 1000L)
    }

    fun stopAuto() { autoSec = 0; ui.removeCallbacks(autoTick) }

    /** Two quick taps in the middle of the screen (likes a reel). */
    fun doubleTap() {
        val m = resources.displayMetrics
        val p = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels / 2f) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 50))
                .addStroke(GestureDescription.StrokeDescription(p, 140, 50))
                .build(), null, null
        )
    }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    /** Turns the current screen into numbered text lines the AI can read. Password fields are hidden. */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(no screen available)"
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("App: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || list.size >= 150 || !n.isVisibleToUser) return
            val txt = (n.text ?: n.contentDescription ?: n.hintText)?.toString()?.replace("\n", " ")?.take(80)
            if (txt != null || n.isClickable || n.isEditable || n.isScrollable) {
                val flags = listOfNotNull(
                    if (n.isClickable) "click" else null,
                    if (n.isEditable) "edit" else null,
                    if (n.isScrollable) "scroll" else null,
                    if (n.isChecked) "checked" else null
                ).joinToString(",")
                val shown = if (n.isPassword) "[hidden password]" else txt ?: ""
                sb.append("[${list.size}] ${n.className?.toString()?.substringAfterLast('.')} \"$shown\" $flags\n")
                list.add(n)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    /** A screenshot the AI can look at (for apps that hide their buttons from accessibility). */
    class Shot(val b64: String, val w: Int, val h: Int, val scale: Float)

    fun screenshot(): Shot? {
        var out: Shot? = null
        val latch = CountDownLatch(1)
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    if (bmp != null) {
                        val k = minOf(1f, 1080f / maxOf(bmp.width, bmp.height))
                        val sm = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
                        val bos = ByteArrayOutputStream()
                        sm.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                        out = Shot(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP), sm.width, sm.height, 1f / k)
                    }
                } catch (e: Exception) {}
                latch.countDown()
            }

            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(4, TimeUnit.SECONDS)
        return out
    }

    fun tapAt(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build(), null, null)
    }

    fun clickNode(id: Int): Boolean {
        val n = nodes.getOrNull(id) ?: return false
        var x: AccessibilityNodeInfo? = n
        while (x != null) {
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent
        }
        val r = Rect(); n.getBoundsInScreen(r)
        tapAt(r.centerX().toFloat(), r.centerY().toFloat())
        return true
    }

    /** Types into the numbered field (or the focused one). Refuses password fields. */
    fun typeInto(id: Int?, text: String): Boolean {
        val n = (if (id != null) nodes.getOrNull(id) else null)
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (n.isPassword) return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressEnter(): Boolean =
        rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) ?: false

    fun type(text: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (n.isPassword) return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Finds a button or label on screen by its text and taps it. */
    fun clickText(txt: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(txt)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                x = x.parent
            }
        }
        return false
    }
}
