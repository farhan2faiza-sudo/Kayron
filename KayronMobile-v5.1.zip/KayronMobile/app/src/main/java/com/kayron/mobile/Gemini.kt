package com.kayron.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class GeminiError(message: String) : Exception(message)

/**
 * Talks to Google's Gemini API (free key from aistudio.google.com/apikey).
 * If one model is busy, rate-limited or retired, it automatically tries the next one.
 */
object Gemini {
    private val FALLBACK = listOf("gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.1-flash-lite")
    @Volatile private var thinkingOk = true

    private class Res(val code: Int, val body: String)

    private fun post(key: String, model: String, body: JSONObject, readMs: Int): Res {
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true
        con.connectTimeout = 15000; con.readTimeout = readMs
        con.setRequestProperty("x-goog-api-key", key)
        con.setRequestProperty("Content-Type", "application/json")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        return Res(code, stream?.bufferedReader()?.readText() ?: "")
    }

    private fun textOf(body: String): String {
        val cands = JSONObject(body).optJSONArray("candidates")
            ?: throw GeminiError("Gemini gave no answer. Please try again.")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiError("Gemini gave no answer. Please try again.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    private fun gen(json: Boolean, temp: Double, maxTokens: Int, think: Boolean, level: String): JSONObject {
        val g = JSONObject().put("temperature", temp)
        if (json) g.put("responseMimeType", "application/json")
        if (maxTokens > 0) g.put("maxOutputTokens", maxTokens)
        if (think) g.put("thinkingConfig", JSONObject().put("thinkingLevel", level))
        return g
    }

    private fun body(system: String, contents: JSONArray, gen: JSONObject): JSONObject = JSONObject()
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        .put("contents", contents)
        .put("generationConfig", gen)

    private fun turn(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    /** Tries each model in turn; handles busy servers, limits, retired models and the thinking setting. */
    private fun execute(c: Context, chain: List<String>, readMs: Int, make: (Boolean) -> JSONObject): String {
        val key = Prefs.key(c)
        var lastCode = 0
        var net: IOException? = null

        for (round in 0..1) {
            for (m in chain) {
                var r: Res
                try {
                    r = post(key, m, make(thinkingOk), readMs)
                    Usage.add(c)
                    if (r.code == 400 && thinkingOk && r.body.contains("thinking", ignoreCase = true)) {
                        thinkingOk = false
                        r = post(key, m, make(false), readMs)
                        Usage.add(c)
                    }
                } catch (e: IOException) { net = e; continue }

                when {
                    r.code in 200..299 -> return textOf(r.body)
                    r.code == 400 && (r.body.contains("API key", true) || r.body.contains("API_KEY", true)) ->
                        throw GeminiError("Your Gemini key is not valid. Please check it in Kayron settings.")
                    r.code == 401 || r.code == 403 ->
                        throw GeminiError("Gemini rejected your key. Please check it in Kayron settings.")
                    r.code == 429 || r.code == 404 || r.code >= 500 -> lastCode = r.code // try the next model
                    else -> throw GeminiError("Gemini had an error, code ${r.code}.")
                }
            }
            if (round == 0 && lastCode != 404) try { Thread.sleep(2500) } catch (e: InterruptedException) {}
        }
        if (lastCode == 0 && net != null) throw net
        throw GeminiError(
            when (lastCode) {
                429 -> "Google's free Gemini limit is used up for now. This limit comes from Google, not from Kayron. Please wait a minute and try again."
                404 -> "Gemini could not find the model. Open Kayron settings and set the model to ${Prefs.DEFAULT_MODEL}."
                else -> "Google's Gemini servers are busy right now. Please try again in a moment."
            }
        )
    }

    /** Agent steps: one JSON reply, optionally with a screenshot. */
    fun ask(c: Context, system: String, prompt: String, imageB64: String? = null): String {
        val chain = (listOf(Prefs.model(c)) + FALLBACK).distinct()
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (imageB64 != null)
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imageB64)))
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
        return execute(c, chain, 60000) { think -> body(system, contents, gen(true, 0.2, 0, think, "low")) }
    }

    /** Code writing: plain text, long answers, deeper thinking, remembers the chat so far. */
    fun code(c: Context, system: String, history: List<Pair<String, String>>, user: String): String {
        val chain = (listOf(Prefs.codeModel(c)) + FALLBACK).distinct()
        val contents = JSONArray()
        for ((u, k) in history.takeLast(6)) {
            contents.put(turn("user", u.take(6000)))
            contents.put(turn("model", k.take(14000)))
        }
        contents.put(turn("user", user))
        return execute(c, chain, 240000) { think -> body(system, contents, gen(false, 0.3, 30000, think, "medium")) }
    }

    /** One careful review pass over a finished answer. */
    fun review(c: Context, system: String, request: String, draft: String): String {
        val chain = (listOf(Prefs.codeModel(c)) + FALLBACK).distinct()
        val contents = JSONArray().put(turn("user", "REQUEST:\n$request\n\nANSWER TO REVIEW:\n$draft"))
        return execute(c, chain, 240000) { think -> body(system, contents, gen(false, 0.1, 30000, think, "medium")) }
    }
}
