package com.kayron.mobile

import android.content.Context
import android.util.Base64
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Real Gmail access (read inbox, search, read an email, send) through Google sign-in. */
object GmailApi {
    private const val READ = "https://www.googleapis.com/auth/gmail.readonly"
    private const val SEND = "https://www.googleapis.com/auth/gmail.send"

    fun options(hint: String? = null): GoogleSignInOptions {
        val b = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail().requestScopes(Scope(READ), Scope(SEND))
        if (hint != null) b.setAccountName(hint)
        return b.build()
    }

    fun account(c: Context): GoogleSignInAccount? =
        GoogleSignIn.getLastSignedInAccount(c)?.takeIf {
            // Gmail only works for the Kayron account that is open and unlocked: accounts never mix
            GoogleSignIn.hasPermissions(it, Scope(READ)) && it.email?.lowercase() == Prefs.profile(c) && Auth.isUnlocked(Prefs.profile(c))
        }

    private fun token(c: Context): String {
        val acc = account(c)?.account ?: throw IllegalStateException("not connected")
        return GoogleAuthUtil.getToken(c, acc, "oauth2:$READ $SEND")
    }

    private fun call(c: Context, method: String, path: String, body: String? = null): JSONObject {
        val con = URL("https://gmail.googleapis.com/gmail/v1/users/me/$path").openConnection() as HttpURLConnection
        con.requestMethod = method; con.connectTimeout = 15000; con.readTimeout = 30000
        con.setRequestProperty("Authorization", "Bearer " + token(c))
        if (body != null) {
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw IllegalStateException("Gmail error $code")
        return JSONObject(txt)
    }

    /** One Gmail action chosen by the AI: unread | list | read | send. Returns text for the AI to use. */
    fun op(c: Context, a: JSONObject): String {
        if (account(c) == null) return "Gmail is not connected for this Kayron account. Tell the user to open the Set up checklist and tap Gmail."
        return try {
            when (a.optString("op")) {
                "unread" -> call(c, "GET", "labels/INBOX").optInt("messagesUnread").toString() + " unread emails in the inbox"
                "list" -> list(c, a.optString("query", "in:inbox"), a.optInt("n", 5).coerceIn(1, 10))
                "read" -> call(c, "GET", "messages/" + a.optString("id") + "?format=full").let {
                    body(it.getJSONObject("payload")).take(1500).ifBlank { "(empty email)" }
                }
                "send" -> send(c, a.optString("to"), a.optString("subject"), a.optString("body"))
                else -> "unknown gmail op"
            }
        } catch (e: Exception) {
            "Gmail failed: ${e.message}"
        }
    }

    private fun list(c: Context, q: String, n: Int): String {
        val ids = call(c, "GET", "messages?maxResults=$n&q=" + URLEncoder.encode(q, "UTF-8")).optJSONArray("messages")
            ?: return "no emails found"
        val sb = StringBuilder()
        for (i in 0 until ids.length()) {
            val id = ids.getJSONObject(i).getString("id")
            val m = call(c, "GET", "messages/$id?format=metadata&metadataHeaders=From&metadataHeaders=Subject")
            val hs = m.getJSONObject("payload").getJSONArray("headers")
            var from = ""; var subj = ""
            for (k in 0 until hs.length()) {
                val hd = hs.getJSONObject(k)
                when (hd.getString("name")) {
                    "From" -> from = hd.getString("value")
                    "Subject" -> subj = hd.getString("value")
                }
            }
            sb.append("id=$id | from: $from | subject: $subj | ${m.optString("snippet").take(120)}\n")
        }
        return sb.toString()
    }

    private fun body(p: JSONObject): String {
        if (p.optString("mimeType") == "text/plain")
            return String(Base64.decode(p.optJSONObject("body")?.optString("data") ?: "", Base64.URL_SAFE))
        val parts = p.optJSONArray("parts") ?: return ""
        for (i in 0 until parts.length()) {
            val s = body(parts.getJSONObject(i))
            if (s.isNotBlank()) return s
        }
        return ""
    }

    private fun send(c: Context, to: String, subject: String, text: String): String {
        if (!to.contains("@")) return "I need a valid email address to send to."
        val raw = "To: $to\r\nSubject: $subject\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n$text"
        call(
            c, "POST", "messages/send",
            JSONObject().put("raw", Base64.encodeToString(raw.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)).toString()
        )
        return "email sent to $to"
    }
}
