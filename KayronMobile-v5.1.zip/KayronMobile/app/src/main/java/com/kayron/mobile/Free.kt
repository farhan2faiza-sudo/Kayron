package com.kayron.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * The free engine: works with NO key and NO sign-up (it uses Pollinations' open endpoints).
 * It is used whenever no Gemini key is saved, or when Gemini is busy.
 * Anonymous use is rate-limited by the provider, so Kayron waits and retries politely.
 */
object FreeAI {
    private const val URL_CHAT = "https://text.pollinations.ai/openai"
    private val MODELS = listOf("openai", "mistral")

    private class Res(val code: Int, val body: String)

    private fun post(model: String, messages: JSONArray, temp: Double, readMs: Int): Res {
        val con = URL(URL_CHAT).openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true
        con.connectTimeout = 15000; con.readTimeout = readMs
        con.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject().put("model", model).put("messages", messages).put("temperature", temp)
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        return Res(code, stream?.bufferedReader()?.readText() ?: "")
    }

    private fun msg(role: String, text: String) = JSONObject().put("role", role).put("content", text)

    private fun run(c: Context, messages: JSONArray, temp: Double, readMs: Int): String {
        var last = 0
        var net: IOException? = null
        for (round in 0..2) {
            for (m in MODELS) {
                try {
                    val r = post(m, messages, temp, readMs)
                    Usage.add(c)
                    if (r.code in 200..299) {
                        val t = try {
                            JSONObject(r.body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                        } catch (e: Exception) { r.body } // some models answer with plain text
                        if (t.isNotBlank()) return t
                    }
                    last = r.code
                } catch (e: IOException) { net = e }
            }
            if (round < 2) try { Thread.sleep(if (last == 429) 8000 else 2500) } catch (e: InterruptedException) {}
        }
        if (last == 0 && net != null) throw net
        throw GeminiError(
            if (last == 429) "The free AI is busy right now (it allows only a few requests at a time). Please wait a few seconds and try again."
            else "The free AI could not answer right now. Please try again in a moment."
        )
    }

    /** Agent steps. The reply is asked to be one JSON object; the agent parses it tolerantly. */
    fun ask(c: Context, system: String, prompt: String, imageB64: String? = null): String {
        val user = if (imageB64 != null)
            JSONObject().put("role", "user").put("content", JSONArray()
                .put(JSONObject().put("type", "text").put("text", prompt))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64"))))
        else msg("user", prompt)
        val sys = system + "\n\nIMPORTANT: reply with ONE valid JSON object only. No text before or after it."
        return try {
            run(c, JSONArray().put(msg("system", sys)).put(user), 0.2, 60000)
        } catch (e: GeminiError) {
            if (imageB64 != null) ask(c, system, prompt, null) else throw e // no vision? try again with text only
        }
    }

    fun code(c: Context, system: String, history: List<Pair<String, String>>, user: String): String {
        val m = JSONArray().put(msg("system", system))
        for ((u, k) in history.takeLast(4)) { m.put(msg("user", u.take(4000))); m.put(msg("assistant", k.take(8000))) }
        m.put(msg("user", user))
        return run(c, m, 0.3, 180000)
    }

    fun review(c: Context, system: String, request: String, draft: String): String =
        run(c, JSONArray().put(msg("system", system)).put(msg("user", "REQUEST:\n$request\n\nANSWER TO REVIEW:\n$draft")), 0.1, 180000)
}

/** Picks Gemini when a key is saved (and falls back to the free engine if Gemini is busy); otherwise the free engine. */
object AI {
    fun usingGemini(c: Context) = Prefs.key(c).isNotBlank()

    fun ask(c: Context, system: String, prompt: String, img: String? = null): String =
        if (usingGemini(c)) try { Gemini.ask(c, system, prompt, img) } catch (e: GeminiError) { FreeAI.ask(c, system, prompt, img) }
        else FreeAI.ask(c, system, prompt, img)

    fun code(c: Context, system: String, history: List<Pair<String, String>>, user: String): String =
        if (usingGemini(c)) try { Gemini.code(c, system, history, user) } catch (e: GeminiError) { FreeAI.code(c, system, history, user) }
        else FreeAI.code(c, system, history, user)

    fun review(c: Context, system: String, request: String, draft: String): String =
        if (usingGemini(c)) try { Gemini.review(c, system, request, draft) } catch (e: GeminiError) { FreeAI.review(c, system, request, draft) }
        else FreeAI.review(c, system, request, draft)
}

/** Makes pictures from a description, with no key. The picture is stored encrypted inside the account. */
object ImageGen {
    private val ASK = Regex(
        "^(?:please\\s+)?(?:(?:can|could) you\\s+)?(?:generate|create|make|draw|paint|design|imagine|render)\\s+(?:me\\s+)?(?:an?\\s+|the\\s+|some\\s+)?" +
            "(?:image|photo|picture|pic|illustration|wallpaper|logo|poster|artwork|art|drawing|painting|portrait|sketch)\\s*(?:of|for|showing|with|about|:|-)?\\s*(.*)$",
        RegexOption.IGNORE_CASE
    )
    private val SLASH = Regex("^/(?:image|imagine|draw|photo)\\s+(.+)$", RegexOption.IGNORE_CASE)

    /** The picture description if the user is asking for a picture, else null. */
    fun wants(goal: String): String? {
        val g = goal.trim()
        SLASH.find(g)?.let { return it.groupValues[1].trim() }
        ASK.find(g)?.let { m ->
            val d = m.groupValues[1].trim().trim('?', '.', '!')
            return d.ifBlank { g }
        }
        return null
    }

    /** Returns a chat message holding a [[img:ID]] marker (the screen turns it into the picture). */
    fun make(c: Context, profile: String, prompt: String): String {
        val seed = (1..999999).random()
        val url = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8").replace("+", "%20") +
            "?width=1024&height=1024&nologo=true&seed=$seed"
        var last = ""
        for (attempt in 0..2) {
            try {
                val con = URL(url).openConnection() as HttpURLConnection
                con.connectTimeout = 15000; con.readTimeout = 120000
                con.setRequestProperty("User-Agent", "KayronMobile/5.1")
                if (con.responseCode in 200..299 && (con.contentType ?: "").startsWith("image")) {
                    val bytes = con.inputStream.use { it.readBytes() }
                    if (bytes.size > 2000) {
                        val id = Chats.saveImage(c, profile, bytes)
                        return "Here you go \uD83C\uDFA8\n[[img:$id]]"
                    }
                }
                last = "code ${con.responseCode}"
            } catch (e: Exception) { last = e.message ?: "network" }
            try { Thread.sleep(if (last.contains("429")) 9000 else 3000) } catch (e: InterruptedException) {}
        }
        return "I could not draw that right now \uD83D\uDE15 (the free picture service said: $last). Please try again in a moment."
    }
}
