package com.kayron.mobile

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

/** Keeps the latest notifications so Kayron can read them out. Long numbers (OTPs) are hidden. */
class KayronNotifications : NotificationListenerService() {
    companion object {
        @Volatile var connected = false
        private val items = CopyOnWriteArrayList<String>()

        fun recent(n: Int): String =
            if (!connected) "Notification access is off. Please allow it in Kayron settings."
            else if (items.isEmpty()) "You have no new notifications."
            else items.take(n).joinToString(". ")
    }

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (x: Exception) { sbn.packageName }
        items.add(0, "$app: $title ${text.replace(Regex("\\b\\d{4,8}\\b"), "[number]")}".trim().take(200))
        while (items.size > 30) items.removeAt(items.size - 1)
    }
}
