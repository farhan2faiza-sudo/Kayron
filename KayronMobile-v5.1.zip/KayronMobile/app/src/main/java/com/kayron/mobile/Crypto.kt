package com.kayron.mobile

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts every account's chats, memory and images with its own AES-256 key.
 * The key lives inside the phone's hardware-backed Keystore and can never be read out of it.
 * Old plain files (from earlier versions) are still readable and are encrypted the next time they are saved.
 */
object Crypto {
    private const val KS = "AndroidKeyStore"
    private val MAGIC = byteArrayOf(0x4B, 0x59, 0x01) // "KY" + version 1

    private fun alias(p: String) = "kayron_" + p.lowercase().replace(Regex("[^a-z0-9@._-]"), "_")

    private fun key(p: String): SecretKey {
        val ks = KeyStore.getInstance(KS).apply { load(null) }
        (ks.getKey(alias(p), null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KS)
        g.init(
            KeyGenParameterSpec.Builder(alias(p), KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    fun enc(p: String, plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(p))
        return MAGIC + c.iv + c.doFinal(plain)
    }

    fun dec(p: String, data: ByteArray): ByteArray {
        if (data.size < 3 + 12 + 16 || !data.copyOfRange(0, 3).contentEquals(MAGIC)) return data // old plain file
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(p), GCMParameterSpec(128, data.copyOfRange(3, 15)))
        return c.doFinal(data, 15, data.size - 15)
    }

    fun write(p: String, f: File, text: String) = f.writeBytes(enc(p, text.toByteArray()))
    fun read(p: String, f: File): String = String(dec(p, f.readBytes()))

    fun deleteKey(p: String) {
        try { KeyStore.getInstance(KS).apply { load(null) }.deleteEntry(alias(p)) } catch (e: Exception) {}
    }
}
