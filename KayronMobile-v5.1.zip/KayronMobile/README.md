# Kayron v5 (Android)

Orange-and-black chat that writes code, answers anything and controls your phone.

- Start screen with the rotating Kayron ring. When you send the first message the ring shrinks to the top left.
- While working, the ring spins faster and the header shows what Kayron is doing (Thinking, Writing code, Reviewing, Polishing).
- Many chats: swipe right (or tap the menu) to open them. Each account (Guest or a Gmail) has its own chat history.
- Code mode: the </> button forces it. It writes code, then a second pass reviews it.
- Phone orders: "next reel", "scroll down", "auto scroll every 10 seconds", "open <app>", "call <name>", "read my notifications"...

Setup: install, then open "Set up Kayron" (gear). No key is needed: Kayron uses a built-in free AI and can draw pictures
("draw a cat astronaut", "/image sunset over a city"). A Gemini key (aistudio.google.com/apikey) is optional, for better answers.

v5.1 changes
- Each Gmail account has its own password (PBKDF2 hash, never stored), its own chats, pictures and memory, all encrypted with a
  key kept in the phone's Keystore. Wrong tries lock the account (30 s, then longer). Optional fingerprint/face unlock.
  The account locks itself after 20 s away from the app, hides from recent apps and screenshots, and Gmail only works for the open account.
  Forgot password: verify with Google + the phone's screen lock, then choose a new one. Long-press an account to remove it and its data.
- Under your message, on the left, a live list shows what Kayron is doing (reading the screen, tapping, typing, drawing...).
- The app logo is now the same rings as in the app (no flame).
- Free AI engine (text.pollinations.ai / image.pollinations.ai). Anonymous use is rate-limited by that service.

Signing key: app/kayron.keystore (password kayron-build-key). SHA-1 for the Gmail OAuth client:
0C:4A:A2:6E:4B:B3:E9:97:E4:FD:A6:19:0E:25:F6:65:E0:5C:F6:5F
For a public release, make your own private key and do not publish it.

Gmail sign-in (optional): Google Cloud > enable Gmail API > OAuth consent (External, add yourself as a test user,
scopes gmail.readonly and gmail.send) > Credentials > OAuth client ID > Android > package com.kayron.mobile + the SHA-1 above.
